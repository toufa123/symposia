<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
	use radiustheme\Eventalk\Helper;
		$btn = $attr = '';
			if ( !empty( $data['buttonurl']['url'] ) ) {
			$attr  = 'href="' . $data['buttonurl']['url'] . '"';
			$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
			$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
		}
		if ( !empty( $data['buttontext'] ) ) {
			$btn = '<a class="btn-fill size-md border-radius-5 color-yellow" ' . $attr . '>' . $data['buttontext'] . '</a>';
		}
			$play_img = Helper::get_img( 'play.png' );
			$size = EVENTALK_CORE_THEME_PREFIX . '-size3';
			$img = wp_get_attachment_image( $data['image']['id'], $size );
	?>
	<div class="about-layout2 rtin-<?php echo esc_attr( $data['layout'] );?>">
		<div class="align-items-center media-none--md">		   
		    <div class="media-body-box">	  
				<div class="video-area overlay-primary80">
			       <?php echo wp_kses_post($img);
			       	if ( !empty( $data['videourl']['url'] ) ) { ?>
				        <a class="play-btn popup-youtube" href="<?php echo esc_url( $data['videourl']['url'] );?>">
				            <img src="<?php echo esc_url($play_img);?>" width="60" height="60" alt="play" class="img-fluid">
				        </a>
			        <?php } ?>
		    	</div>
			    <div class="vcontent-area">
			       <h3 class="title-bold color-primary margin-b-20"><?php echo wp_kses_post( $data['title'] );?></h3>
			        <p><?php echo wp_kses_post( $data['content'] );?></p>
					<?php if ( $btn ): ?>
						<div class="rtin-button"><?php echo wp_kses_post( $btn );?></div>		
					<?php endif; ?>
			    </div>		    
		    </div>		    
		</div>
	</div>