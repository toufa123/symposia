<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Eventalk_Core;
use radiustheme\Eventalk\Helper;
	$slides = array();
	$default_img = Helper::get_img( 'noslider.jpg' );
	foreach ( $data['slides2'] as $slide ) {
		$slides[] = array(
			'id'           		 => 'slide-' . time().rand( 1, 99 ),
			'image'        		 => $slide['image']['url'] ? $slide['image']['url'] : $default_img,
		
		);
	}
	$btn = $attr = '';
	if ( !empty( $data['buttonurl']['url'] ) ) {
		$attr  = 'href="' . $data['buttonurl']['url'] . '"';
		$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
		$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
		
	}
	if ( !empty( $data['buttontext'] ) ) {
		$btn = '<a class="btn-ghost color-light hover-yellow size-lg border-radius-5" ' . $attr . '>' . $data['buttontext'] . '</a>';
	}
	if(!empty($data['countdown'])){
		$date = date("Y/m/d", strtotime($data['countdown']));
	}	
?>

<div class="rt-el-slider slider-area slider-layout3">	
  <div class="comingsoon-inner">
        <div class="container">
            <div class="comingsoon-content">
                 <div class="upcoming-event-info">
                   <?php echo wp_kses_post( $data['subtitle'] );?>
                </div>
                  <h1><?php echo esc_attr( $data['title'] );?></h1>
                <div class="countdown-layout3">
                   <div data-countdown="<?php echo esc_attr( $date );?>" id="countdown"></div>
                </div>
                <div class="row d-none d-xl-block">
                    <div class="col-12 text-center">                      
                        <?php echo wp_kses_post( $btn );?>       
                    </div>
                </div>
            </div>
        </div>
    </div>	
	<div class="rt-nivoslider slider-gradient-overlay">
		<?php foreach ( $slides as $slide ): ?>
			<img src="<?php echo esc_url( $slide['image'] );?>" alt="<?php echo wp_kses_post( $slide['title'] );?>" title="#<?php echo esc_attr( $slide['id'] );?>" />
		<?php endforeach; ?>
	</div>
</div>