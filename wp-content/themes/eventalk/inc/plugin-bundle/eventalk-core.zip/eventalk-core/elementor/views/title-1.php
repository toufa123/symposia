<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
?>
<div class="rt-el-title section-heading title-black color-light text-center <?php echo esc_html( $data['style'] );?>">
	<h2 class="rtin-title"><?php echo esc_html( $data['title'] );?></h2>
	<div class="rtin-subtitle"><p><?php echo wp_kses_post( $data['subtitle'] );?></p></div>
</div>
