<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.2
 */

namespace radiustheme\Eventalk_Core;

use \WP_Query;
use radiustheme\Eventalk\RDTheme;
use radiustheme\Eventalk\Helper;
$prefix      = EVENTALK_CORE_THEME_PREFIX;
$cpt         = EVENTALK_CORE_CPT_PREFIX;
$thumb_size  = "{$prefix}-size4";
$args = array(
    'post_type'         => "{$cpt}_event",
    'p'                 => $data['event_id'],
    'posts_per_page'    => 1,
    'post_status'       => 'publish'
);
$query = new WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="schedule-layout-wrp">      
    <?php if ( $query->have_posts() ) :?>
        <?php while ( $query->have_posts() ) : $query->the_post();?>
                <?php
                $id                  = get_the_id();    
                $_event_start_date  = get_post_meta( $id, "{$cpt}_event_start_date", true );
                $_event_start_time  = get_post_meta( $id, "{$cpt}_event_start_time", true );
                $_event_end_date    = get_post_meta( $id, "{$cpt}_event_end_date", true );
                $_event_end_time    = get_post_meta( $id, "{$cpt}_event_end_time", true );
                $_event_location    = get_post_meta( $id, "{$cpt}_event_location", true );
                $_event_lat         = get_post_meta( $id, "{$cpt}_event_lat", true );
                $_event_lan         = get_post_meta( $id, "{$cpt}_event_lan", true );
                $_event_ext_link    = get_post_meta( $id, "{$cpt}_event_ext_link", true );
                $schedules          = get_post_meta( $id, 'eventalk_event_schedule', true);     
                $buttontext         = $data['buttontext'];
                $buttonurl          = $data['buttonurl'];  
                $socials            = get_post_meta($id, "{$cpt}_event_social", true );
                $socials            = array_filter($socials);
                $social_fields      = Helper::event_socials();               
                $starDate           = Helper::custom_date_format($_event_start_date);            
                $endDate            = Helper::custom_date_format($_event_end_date);
                $dStart             = new \DateTime($starDate);                
                $dEnd               = new \DateTime($endDate);
                $dDiff              = $dStart->diff($dEnd);
                $difday             = $dDiff->days;     
                ?>
            <?php //if($difday){ ?>
                <div class="schedule-wrapper-8">
                    <?php for($i = 0; $i <= $difday; $i++) {

                        $datetime = new \DateTime($starDate);
                        $datetime->modify('+'.$i.' day');
                        $dayNumber = $i + 1;
                        $sdl  = array();

                        foreach ($schedules as $schedule) {

                             if(Helper::custom_date_format( $schedule['session_start_date'], 'm/d/Y' ) == $datetime->format('m/d/Y')){  
                                $schedule['day_number'] = $dayNumber;
                                $schedule['date'] = $datetime->format($data['date_format'] );
                                $sdl[] = $schedule;
                            }
                        }
                        if(!empty($sdl)){
                            ?>
                            <div class="schedule-header">   
                                    <div class="schedule-date">
                                       <div class="day-number"><span class="day-number-left">
                                        <?php  echo esc_html(date_i18n( $data['date_format'], strtotime($datetime->format('Ymd')))); ?> : 
                                    </span>
                                           <?php if ( $data['schedule_label_display'] == 'style1'  ) {  ?>  
                                                  <?php echo esc_html__( 'Day', 'eventalk' );?> - 0<?php echo esc_html($dayNumber); ?>
                                           <?php } else { ?>
                                                    <?php echo esc_attr(Helper::get_label_by_day_number($sdl, $dayNumber)); ?>
                                           <?php } ?>                                     
                                        </div>
                                    </div>
                                </div>
                            <div class="schedule-item-8">
                                <?php foreach ($sdl as $item) { 
                                        $sDate           = \DateTime::createFromFormat('m/d/Y', $item['session_start_date']);
                                            $schedule_speaker_title = esc_attr(get_the_title($item['speaker'])) ;                 
                                            $schedule_speaker_img = get_the_post_thumbnail_url($item['speaker'], 'thumbnail' ) ;
                                            if (!empty($item['speaker2'])) {
                                                $schedule_speaker_title2 = esc_attr(get_the_title($item['speaker2'])) ;                 
                                                $schedule_speaker_img2 = get_the_post_thumbnail_url($item['speaker2'], 'thumbnail' ) ;   
                                            }
                                        ?>     
                                        <div class="schedule-contnet-mid">    
                                            <div class="row">    
                                                <div class="col-lg-2 col-md-3 col-sm-12"> 
                                                    <div class="schedule-time">
                                                    <i class="fa fa-clock-o" aria-hidden="true"></i><?php echo wp_kses_post($item['session_start_time']); ?> - <?php echo esc_html($item['session_end_time']); ?>
                                                </div>
                                                </div>   

                                                <div class="col-lg-2 col-md-2 col-sm-12 p0"> 
                                                    <div class="speaker-new-wrp"> 
                                                                <ul class="schedule-speaker">                           
                                                         <?php if($item['speaker']){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker'])) ; ?>
                                                                </div>

                                                                </li>    
                                                             
                                                            <?php  } ?> 
                                                        <?php  } ?>        
                                                         <?php if($item['speaker2']){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker2'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker2']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker2'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker2'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?>    
                                                         <?php if($item['speaker3']){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker3'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker3']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker3'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker3'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?>  
                                                         <?php if($item['speaker4']){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker4'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker4']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker4'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker4'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?>      
                                                        <?php if($item['speaker5']){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker5'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker5']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker5'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker5'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?>    
                                                        <?php if($item['speaker6']){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker6'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker6']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker6'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker6'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?> 

                                                        <?php if( !empty( $item['speaker7'] ) ){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker7'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker7']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker7'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker7'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?>

                                                        <?php if( !empty( $item['speaker8'] ) ){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker8'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker8']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker8'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker8'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?>

                                                        <?php if( !empty( $item['speaker9'] ) ){ ?>
                                                            <?php if($schedule_speaker_img){ ?>
                                                                                         
                                                                    <li>
                                                                        <div class="speaker-img-tooltip" data-tips="<?php  echo  esc_attr(get_the_title($item['speaker9'])) ;?>">
                                                                        <a href="<?php echo get_permalink( $item['speaker9']); ?>">
																<?php echo get_the_post_thumbnail($item['speaker9'], 'thumbnail',['class' => 'rounded-circle'] ) ; ?></a>
                                                                    </div>   
                                                                    
                                                                <?php }else {  ?>
                                                                    <div class="title_sp text-right"> 
                                                                     <?php   echo esc_attr(get_the_title($schedule['speaker9'])) ; ?>
                                                                </div>
                                                                </li>    
                                                               
                                                            <?php  } ?> 
                                                        <?php  } ?>

                                                    </ul>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-md-6 col-sm-12"> 
                                                    <div class="speaker-new-wrp"> 
                                                      <h3 class="schedule-title">
                                                            <?php if ($data['event_link']) { ?>
                                                                <a href="<?php the_permalink();?>"><?php echo esc_attr($item['session_title']); ?></a>
                                                            <?php  } else {       ?>                                               
                                                                <?php echo esc_attr($item['session_title']); ?>
                                                            <?php } ?>      
                                                        </h3>
                                                        <ul class="schedule-list-info">
                                                            <li>
                                                                 <?php if($item['speaker']){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker'])) ;?> &nbsp;
                                                                <?php } ?> 

                                                                <?php if($item['speaker2']){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker2'])) ;?> &nbsp;
                                                                <?php } ?>  

                                                                <?php if($item['speaker3']){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker3'])) ;?> &nbsp;
                                                                <?php } ?>  

                                                                <?php if($item['speaker4']){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker4'])) ;?> &nbsp;
                                                                <?php } ?>  

                                                                <?php if($item['speaker5']){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker5'])) ;?> &nbsp;
                                                                <?php } ?>  

                                                                <?php if($item['speaker6']){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker6'])) ;?> &nbsp;
                                                                <?php } ?>  

                                                                <?php if( !empty( $item['speaker7']) ){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker7'])) ;?> &nbsp;
                                                                <?php } ?>  

                                                                <?php if( !empty( $item['speaker8']) ){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker8'])) ;?> &nbsp;
                                                                <?php } ?>
                                                                
                                                                <?php if( !empty( $item['speaker9']) ){ ?>
                                                                    <i class="fa fa-user" aria-hidden="true"></i> <?php  echo esc_attr(get_the_title($item['speaker9'])) ;?> &nbsp;
                                                                <?php } ?>                                                                                                                                                                                          
                                                            </li>
                                                            <?php  if($data['hall_address']){ ?>  
                                                                <li>
                                                                    <i class="fa fa-map-marker" aria-hidden="true"></i> <?php  echo  esc_attr($item['schedule_Hall']) ;?></li>
                                                             <?php } ?> 
                                                        </ul>
                                                    <?php if ($data['details_toggle']) { ?>                                                        
                                                        <div class="details-txt">
                                                            <p><?php  echo esc_attr($item['session_details']) ;?></p>
                                                        </div>

                                                    <?php  } else { ?>
                                                     <div class="details-show">
                                                            <p><?php  echo esc_attr($item['session_details']) ;?></p>
                                                        </div>                                                   
                                                    <?php }
                                                    ?>      

                                                    </div> 
                                                </div> 
                                            <div class="col-lg-2 col-md-2 col-sm-12">
                                                <div class="speaker-details-wrp details-info">
                                                    <?php if ($data['details_toggle']) { ?>                                                        
                                                    <a class="details-down" href="#"><?php echo esc_html__( 'Details', 'eventalk-core' );?></a>
                                                  <?php  } else { ?>
                                                    <a class="btn-ghost-sm border-radius-5 margin-t-20" href="<?php the_permalink();?>"><?php echo esc_html__( 'View Details', 'eventalk-core' );?></a>                                                    
                                                   <?php }
                                                     ?>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            <?php } // End foreach ?>
                            </div>
                        <?php 
                        } // End sdl if
                  } //End for loop?>
                </div>
            <div class="row event-social-wrp">
                <?php if($buttonurl): ?>               
                  <div class="col-xl-12 text-center"> 
                    <a href="<?php echo esc_url($buttonurl);?>" title="<?php echo esc_html($buttontext);?>" class="loadmore-four-item btn-fill border-radius-5 size-lg color-yellow margin-t-20"><?php echo esc_html( $buttontext);?></a>
                </div>                 
                <?php endif; ?>              
            </div> 
            <?php // }  // End if day have if
            endwhile; // End if have post while loop?>
    <?php endif; ?>
    <?php Helper::wp_reset_temp_query( $temp );?>
</div>

