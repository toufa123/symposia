<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Custom_Widget_Init {

	public function __construct() {
		add_action( 'elementor/widgets/widgets_registered', array( $this, 'init' ) );
		add_action( 'elementor/elements/categories_registered', array( $this, 'widget_categoty' ) );
	}

	public function init() {
		require_once __DIR__ . '/base.php';
		// Widgets -- filename=>classname /@dev
		$widgets = array(
			'title'           => 'Title',
			'cta'             => 'CTA',
			'event'           => 'Event',
			'event-multiple'  => 'Event_Multiple',
			'text-with-title' => 'Text_With_Title',
			'info-box'        => 'Info_Box',
			'video-with-title' => 'Video_With_Title',
			'full-banner' 	  => 'full_banner',		
			'slider'          => 'Slider',		
			'countdown'       => 'CountDown',
			'logo-slider'     => 'Logo_Slider',			
			'logo-grid'       => 'Logo_Grid',			
			'contact'         => 'Contact',
			'nav-menu'        => 'Nav_Menu',
			'speaker-grid'    => 'Speaker_Grid',
			'speaker-slider'  => 'Speaker_slider',
			'price-plan' 	  => 'Price_Plan',
			'blog-post' 	  => 'Blog_post',
			'post-slider'     => 'Post_Slider',		
			'gallrey'         => 'Gallrey',
						
		);
		foreach ( $widgets as $widget => $class ) {
			$template_name = "/elementor-custom/widgets/{$widget}.php";
			if ( file_exists( STYLESHEETPATH . $template_name ) ) {
				$file = STYLESHEETPATH . $template_name;
			}
			elseif ( file_exists( TEMPLATEPATH . $template_name ) ) {
				$file = TEMPLATEPATH . $template_name;
			}
			else {
				$file = __DIR__ . '/widgets/' . $widget. '.php';
			}

			require_once $file;
			
			$classname = __NAMESPACE__ . '\\' . $class;
			Plugin::instance()->widgets_manager->register_widget_type( new $classname );
		}
	}

	public function widget_categoty( $class ) {
		$id         = EVENTALK_CORE_THEME_PREFIX . '-widgets'; // Category /@dev
		$properties = array(
			'title' => esc_html__( 'RadiusTheme Elements', 'eventalk-core' ),
		);

		Plugin::$instance->elements_manager->add_category( $id, $properties );
	}
}

new Custom_Widget_Init();