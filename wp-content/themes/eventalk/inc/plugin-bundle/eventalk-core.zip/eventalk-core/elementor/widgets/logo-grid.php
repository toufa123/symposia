<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use Elementor\Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;
class Logo_Grid extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Logo Grid', 'eventalk-core' );
		$this->rt_base = 'rt-logo-grid';
		$this->rt_translate = array(
			'cols'  => array(
				'1'  => esc_html__( '1 Col', 'eventalk-core' ),
				'2'  => esc_html__( '2 Col', 'eventalk-core' ),
				'3'  => esc_html__( '3 Col', 'eventalk-core' ),
				'4'  => esc_html__( '4 Col', 'eventalk-core' ),				
				'6'  => esc_html__( '6 Col', 'eventalk-core' ),
			),
		);
		parent::__construct( $data, $args );
	}
	
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'eventalk-core' ),
				'default' => 'Lorem Ipsum',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'grey_scale',
				'label'       => esc_html__( 'Grey Scale ', 'eventalk-core' ),
				'label_on'    => esc_html__( 'On', 'eventalk-core' ),
				'label_off'   => esc_html__( 'Off', 'eventalk-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Grey Scale. Default: On', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'logos',
				'label'   => esc_html__( 'Add as many logos as you want', 'eventalk-core' ),
				'fields'  => array(
					array(
						'type'  => Controls_Manager::MEDIA,
						'name'  => 'image',
						'label' => esc_html__( 'Image', 'eventalk-core' ),
					),
					array(
						'type'  => Controls_Manager::TEXT,
						'name'  => 'url',
						'label' => esc_html__( 'URL(optional)', 'eventalk-core' ),
					),
				),
			),
			array(
				'mode' => 'section_end',
			),

			// Responsive Columns
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_responsive',
				'label'   =>esc_html__( 'Number of Responsive Columns', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_lg',
				'label'   =>esc_html__( 'Desktops: > 1199px', 'eventalk-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '3',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_md',
				'label'   =>esc_html__( 'Desktops: > 991px', 'eventalk-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '3',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_sm',
				'label'   =>esc_html__( 'Tablets: > 767px', 'eventalk-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '4',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_xs',
				'label'   =>esc_html__( 'Phones: < 768px', 'eventalk-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_mobile',
				'label'   =>esc_html__( 'Small Phones: < 480px', 'eventalk-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'mode' => 'section_end',
			),

			
		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();
		$template = 'logo-grid';
		return $this->rt_template( $template, $data );
	}
}