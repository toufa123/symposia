<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Eventalk_Core;
use \WP_Query;
use radiustheme\Eventalk\RDTheme;
use radiustheme\Eventalk\Helper;

$prefix      = EVENTALK_CORE_THEME_PREFIX;
$cpt         = EVENTALK_CORE_CPT_PREFIX;
$thumb_size  = "{$prefix}-size4";
$args = array(
	'post_type'      => "{$cpt}_speaker",
	'posts_per_page' => $data['number'],
	'orderby'        => $data['orderby'],
);
if ( !empty( $data['cat'] ) ) {
	$args['tax_query'] = array(
		array(
			'taxonomy' => "{$cpt}_speaker_category",
			'field' => 'term_id',
			'terms' => $data['cat'],
		)
	);
}
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}
$query = new WP_Query( $args );
$class = $data['slider_nav'] == 'yes' ? ' slider-nav-enabled' : '';
$temp = Helper::wp_set_temp_query( $query )
?>
<div class="rc-carousel  <?php echo esc_attr( $class );?>">
	<div class="nav-control-layout2 owl-theme owl-carousel rt-owl-carousel" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">

		<?php if ( $query->have_posts() ) :?>
			<?php while ( $query->have_posts() ) : $query->the_post();?>
				<?php
					$id            = get_the_id();
					$designation   = get_post_meta( $id, "{$cpt}_speaker_designation", true );
					$socials       = get_post_meta( $id, "{$cpt}_speaker_social", true );
					$social_fields = Helper::speakers_socials();
					$content = Helper::get_current_post_content();
					$content = wp_trim_words( $content, $data['count'] );
					$content = "<p>$content</p>";
				?>
				<div class="rtin-item">
					<div class="speaker-layout1 text-center">
						<div class="item-img">	
						    <?php
							if ( has_post_thumbnail() ){
								the_post_thumbnail( $thumb_size );
							}
							else {
								if ( !empty( RDTheme::$options['no_preview_image']['id'] ) ) {
									echo wp_get_attachment_image( RDTheme::$options['no_preview_image']['id'], $thumb_size );
								}
								else {
									echo '<img class="wp-post-image img-fluid rounded-circle" src="' . Helper::get_img( 'noimage_430x430.jpg' ) . '" alt="'.get_the_title().'">';
								}
							}
							?>
							 <?php if ( !empty($data['social_display'] ) ): ?>
						    <div class="item-social">
						        <ul>
								<?php foreach ( $socials as $key => $social ): ?>
									<?php if ( !empty( $social ) ): ?>
										<li><a target="_blank" href="<?php echo esc_url( $social );?>"><i class="fa <?php echo esc_attr( $social_fields[$key]['icon'] );?>" aria-hidden="true"></i></a></li>
									<?php endif; ?>
								<?php endforeach; ?>
						        </ul>
						    </div>
						    <?php endif; ?>
						</div>
						<div class="item-title">
						    <h3 class="title-medium color-light size-md hover-yellow">
								<?php if ( !empty($data['title_link_display'] ) ): ?>
									<a href="<?php the_permalink();?>"><?php the_title();?></a>
								<?php endif; ?>
								<?php if ( empty($data['title_link_display'] ) ): ?>
									<?php the_title();?>
								<?php endif; ?>
						    </h3>
						    <?php if ( !empty( $data['designation_display'] ) ): ?>
				       		<div class="text-center title-light size-md color-light"><?php echo esc_attr( $designation );?></div>
				       	<?php endif; ?>
						</div>
					</div>
				</div>				
			<?php endwhile;?>
		<?php endif;?>
		<?php Helper::wp_reset_temp_query( $temp );?>
	</div>
	</div>