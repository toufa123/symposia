<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
use radiustheme\Eventalk\Helper;
	$btn = $attr = '';
		if ( !empty( $data['buttonurl']['url'] ) ) {
		$attr  = 'href="' . $data['buttonurl']['url'] . '"';
		$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
		$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	}
	if ( !empty( $data['buttontext'] ) ) {
		$btn = '<a class="btn-fill size-md border-radius-5 color-yellow" ' . $attr . '>' . $data['buttontext'] . '</a>';
	}
		
		$size = 'full';
		$img = wp_get_attachment_image( $data['image']['id'], $size );
?>
	<div class="about-layout2 rtin-<?php echo esc_attr( $data['layout'] );?>">
		<div class="align-items-center media-none--md">
		    <div class="video-area">
		       <?php echo wp_kses_post($img); ?>

		        <?php if ( !empty(  $data['title'] ) ) { ?>
		        	 <h3 class="title-bold color-primary size-lg margin-b-20"><?php echo wp_kses_post( $data['title'] );?></h3>
		         <?php } ?>


				<?php 
		       	if ( !empty( $data['videourl']['url'] ) ) { ?>
		       		 <?php if ( !empty(  $data['title'] ) ) { ?>				        


	<div class="video-icon"><a class="play-btn popup-video popup-youtube rtin-<?php echo esc_attr( $data['layout'] );?>" href="<?php echo esc_url( $data['videourl']['url'] );?>">		
	 <i class="fa fa-play" aria-hidden="true"></i>
	</a></div>


		          <?php }else{ ?>
						
	<div class="video-icon"><a class="play-btn popup-video popup-youtube" href="<?php echo esc_url( $data['videourl']['url'] );?>">		
	 <i class="fa fa-play" aria-hidden="true"></i>
	</a></div>

		          <?php } ?>
		        <?php } ?>



		    </div>		   
		</div>
	</div>