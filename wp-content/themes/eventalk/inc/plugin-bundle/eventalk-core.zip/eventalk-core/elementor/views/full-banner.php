<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

$btn = $attr = '';
if ( !empty( $data['buttonurl']['url'] ) ) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( !empty( $data['buttontext'] ) ) {
	$btn = '<a class="btn-fill size-lg border-radius-5 color-yellow gust" ' . $attr . '>' . $data['buttontext'] . '</a>';
}
if(!empty($data['countdown'])){
	$date = date("Y/m/d", strtotime($data['countdown']));
}
?>
<!-- Slider Area Start Here -->
<div class="slider-layout2 overlay-icon-layout6 rtin-<?php echo esc_attr( $data['theme'] );?>">
    <?php echo wp_get_attachment_image( $data['image']['id'], 'full', "", array( "class" => "img-responsive img-fluid" ) );  ?>
    <div class="comingsoon-inner">       
        <div class="comingsoon-content">
            <p class="text-underline"><?php echo esc_attr( $data['title'] );?></p>
            <div class="upcoming-event-info">
               <?php echo wp_kses_post( $data['subtitle'] );?>
            </div>
            <div class="countdown-layout2 d-none d-sm-block">               
                <div data-countdown="<?php echo esc_attr( $date );?>" class="event-countdown"></div>
            </div>
            <div class="row">
                <div class="col-12 text-center d-none d-md-block ">
                	<?php echo wp_kses_post( $btn );?>                       
                </div>
            </div>
        </div>       
    </div>
</div>
<!-- Slider Area End Here -->