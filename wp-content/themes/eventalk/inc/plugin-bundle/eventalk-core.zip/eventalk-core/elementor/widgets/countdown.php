<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class CountDown extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'CountDown', 'eventalk-core' );
		$this->rt_base = 'rt-countdown';
		parent::__construct( $data, $args );
	}
	private function rt_load_scripts(){
		wp_enqueue_script( 'countdown' );			
	}
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'eventalk-core' ),
				'options' => array(
					'style1' 		=> esc_html__( 'Style 1', 'eventalk-core' ),
					'style2' 		=> esc_html__( 'Style 2', 'eventalk-core' ),				
					'style3' 		=> esc_html__( 'Style 3', 'eventalk-core' ),				
					
				),
				'default' => 'style1',
			),	
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'theme',
				'label'   => esc_html__( 'Theme', 'eventalk-core' ),
				'options' => array(
					'light' => esc_html__( 'Light Background', 'eventalk-core' ),
					'dark'  => esc_html__( 'Dark Background', 'eventalk-core' ),
				),
				'default' => 'light',
			),	
			array(
				'type' => Controls_Manager::DATE_TIME,
				'id'      => 'countdown',
				'label'   => esc_html__( 'Event Date Time', 'eventalk-core' ),
				'default' => 2018,
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		$this->rt_load_scripts();
		switch ( $data['style'] ) {
			case 'style2':
				$template = 'countdown-2';
			break;	
			case 'style3':
				$template = 'countdown-3';
			break;			
			default:
				$template = 'countdown';
			break;
		}
		return $this->rt_template( $template, $data );
	}
}