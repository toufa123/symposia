<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class Full_Banner extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'FullScreen Banner', 'eventalk-core' );
		$this->rt_base = 'rt-full-banner';
		parent::__construct( $data, $args );
	}
		private function rt_load_scripts(){
		wp_enqueue_script( 'countdown' );	
	}
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'theme',
				'label'   => esc_html__( 'Theme', 'eventalk-core' ),
				'options' => array(
					'light' => esc_html__( 'Light Background', 'eventalk-core' ),
					'dark'  => esc_html__( 'Dark Background', 'eventalk-core' ),
				),
				'default' => 'light',
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'    => 'image',
				'label'   => esc_html__( 'Image', 'eventalk-core' ),
				'description' => esc_html__( 'Image size should be 1920x820 px', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'    => 'title',
				'label'   => esc_html__( 'Title', 'eventalk-core' ),
				'default' => 'Marketing Conferencee 2018',
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'    => 'subtitle',
				'label'   => esc_html__( 'Subtitle', 'eventalk-core' ),
				'default' => '17 - 25 December 2018 Tobacco Dock, London ',
			),
			array(
				'type' => Controls_Manager::DATE_TIME,
				'id'      => 'countdown',
				'label'   => esc_html__( 'Event Date Time', 'eventalk-core' ),
				'default' => 2018,
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'eventalk-core' ),
				'default' => 'Buy Tickets Now!',
			),
			array(
				'type'    => Controls_Manager::URL,
				'id'      => 'buttonurl',
				'label'   => esc_html__( 'Button URL', 'eventalk-core' ),
				'placeholder' => 'https://your-link.com',
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();	
		$this->rt_load_scripts();
		$template = 'full-banner';
		return $this->rt_template( $template, $data );
	}
}