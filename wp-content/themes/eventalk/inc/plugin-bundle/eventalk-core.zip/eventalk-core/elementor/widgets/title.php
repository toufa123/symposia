<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
use Elementor\Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;
class Title extends Custom_Widget_Base {
    public function __construct( $data = [], $args = null ){
            $this->rt_name = esc_html__( 'Section Title', 'eventalk-core' );
            $this->rt_base = 'rt-title';
            parent::__construct( $data, $args );
    }
    public function rt_fields(){
            $fields = array(
                    array(
                            'mode'    => 'section_start',
                            'id'      => 'sec_general',
                            'label'   => esc_html__( 'General', 'eventalk-core' ),
                    ),
                     array(
                            'type'    => Controls_Manager::SELECT2,
                            'id'      => 'style',
                            'label'   => esc_html__( 'Style', 'eventalk-core' ),
                            'options' => array(
                                    'style1' => esc_html__( 'Style 1', 'eventalk-core' ),
                                    'style2' => esc_html__( 'Style 2', 'eventalk-core' ),					
                                    'style3' => esc_html__( 'Style 3', 'eventalk-core' ),
                                    'style4' => esc_html__( 'Style 4', 'eventalk-core' ),
                                    'style5' => esc_html__( 'Style 5', 'eventalk-core' ),
                            ),
                            'default' => 'style1',
                    ),	
                    array(
                            'type'    => Controls_Manager::TEXT,
                            'id'      => 'title',
                            'label'   => esc_html__( 'Title', 'eventalk-core' ),
                            'default' => 'Lorem Ipsum',
                    ),
                    array(
                            'type'    => Controls_Manager::TEXTAREA,
                            'id'      => 'subtitle',
                            'label'   => esc_html__( 'Subtitle', 'eventalk-core' ),
                            'default' => 'Lorem Ipsum has been standard daand scrambled. Rimply dummy text of the printing and typesetting industry',
                            'condition'   => array( 'style' => array( 'style1','style2','style3','style5')),
                    ),                   
                    array(
                            'type'    => Controls_Manager::COLOR,
                            'id'      => 'title_color',
                            'label'   => esc_html__( 'Title Color', 'eventalk-core' ),
                            'default' => '#282828',
                            'selectors' => array( '{{WRAPPER}} .rtin-title' => 'color: {{VALUE}}' ),
                    ),
                    array(
                            'type'    => Controls_Manager::COLOR,
                            'id'      => 'subtitle_color',
                            'label'   => esc_html__( 'Subtitle Color', 'eventalk-core' ),
                            'default' => '#444444',
                            'selectors' => array( '{{WRAPPER}} .rtin-subtitle' => 'color: {{VALUE}}' ),
                            'condition'   => array( 'style' => array( 'style1','style2','style3')),
                    ),
                    array(
                            'mode' => 'section_end',
                    ),
            );
            return $fields;
    }
    protected function render() {
        $data = $this->get_settings();
            switch ( $data['style'] ) {
            case 'style2':
                $template = 'title-2';
            break;
            case 'style3':
                $template = 'title-3';
            break;       
            case 'style4':
                $template = 'title-4';
            break; 
            case 'style5':
                $template = 'title-5';
            break;
            default:
                $template = 'title-1';
            break;
        }
        return $this->rt_template( $template, $data );
    }
}