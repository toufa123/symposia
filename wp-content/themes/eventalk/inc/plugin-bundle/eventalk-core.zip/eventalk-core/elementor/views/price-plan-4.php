<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
use radiustheme\Eventalk\Helper;
$options = array();
$title    = $data['title'];
$price    = $data['price'];
$currency   = $data['currency'];
$buttontext = $data['buttontext'];
$buttonurl  = $data['buttonurl'];
foreach ( $data['options'] as $option ) {
  $options[] = array(       
    'option_title'   => $option['option_title'],    
    'option_select_loop'   => $option['option_select_loop'],    
  );
}
$btn_class= '';
switch ( $data['button_style'] ) {
  case 'style2':
  $btn_class = 'btn-fill size-md color-primary border-radius-5';  
  break;
  case 'style3':
  $btn_class = 'btn-fill size-md color-green border-radius-5';
  break;  
  default:
  $btn_class = 'btn-fill size-md color-yellow border-radius-5';
  break;
}
?>
<div class="price-table-layout4">
    <div class="item-wrapper">
      <div class="item-wrapper-mid">

          <div class="item-title">
              <h3 class="title-medium color-dark text-uppercase"><?php echo wp_kses_post( $title );?></h3>
          </div>
          <div class="item-price"><?php echo esc_attr($price); ?>
              <span class="currency"><?php echo esc_attr($currency); ?></span>
          </div>
          <div class="item-body">
              <ul>
                <?php foreach ( $options as $option ): ?>
                  <li class="<?php echo wp_kses_post( $option['option_select_loop'] );?>"><?php echo wp_kses_post( $option['option_title'] );?></li>
                <?php endforeach; ?>   
              </ul>
          </div>
          <a href="<?php echo esc_url($buttonurl);?>" title="<?php echo esc_html($buttontext);?>" class="<?php echo esc_html($btn_class);?>"><?php echo esc_html( $buttontext);?></a>

      </div>
    </div>
</div>
