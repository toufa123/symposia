<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

if(!empty($data['countdown'])){
$countdown_time  = strtotime( $data['countdown'] );
$date  = date('Y/m/d H:i:s', $countdown_time);
}
?>
<div class="full-width-container countdown-layout3new rtin-<?php echo esc_attr( $data['theme'] );?>">
    <div class="container-fluid-wrp">
        <div data-countdown="<?php echo esc_attr( $date );?>" class="event-countdown"></div>
    </div>
</div>