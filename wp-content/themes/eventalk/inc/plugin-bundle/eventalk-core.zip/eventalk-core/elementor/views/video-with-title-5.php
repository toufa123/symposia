<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
use radiustheme\Eventalk\Helper;
?>
<div class="video-layout7 rtin-<?php echo esc_attr( $data['layout'] );?>">
	<div class="align-items-center">				
	    <div class="vcontent-area">

		<?php  if ( !empty( $data['subtitle'] ) ) { ?>
			<div class="subtitle border-after"><?php echo wp_kses_post( $data['subtitle'] );?></div>
		<?php } ?>

       	<h3 class="v-title-7 margin-b-20"><?php echo wp_kses_post( $data['title'] );?></h3>
		
		<?php  if ( !empty( $data['content'] ) ) { ?>
			<p class="v-content"><?php echo wp_kses_post( $data['content'] );?></p>
		<?php } ?>
	
		<?php  if ( !empty( $data['videourl']['url'] ) ) { ?>
			<a class="play-btn-7 popup-youtube" href="<?php echo esc_url( $data['videourl']['url'] );?>">
				<i class="fa fa-play"></i> <span><?php echo wp_kses_post( $data['videobtntext'] );?></span>
			</a>
		<?php } ?>

	    </div>	
	</div>
</div>