<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use \WP_Query;
use radiustheme\Eventalk\RDTheme;
use radiustheme\Eventalk\Helper;

$prefix      = EVENTALK_CORE_THEME_PREFIX;
$cpt         = EVENTALK_CORE_CPT_PREFIX;
$thumb_size  = "{$prefix}-size4";
$args = array(
	'post_type'      => "{$cpt}_speaker",
	'posts_per_page' => $data['number'],
	'orderby'        => $data['orderby'],
);
if ( !empty( $data['cat'] ) ) {
	$args['tax_query'] = array(
		array(
			'taxonomy' => "{$cpt}_speaker_category",
			'field' => 'term_id',
			'terms' => $data['cat'],
		)
	);
}
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}
$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="rt-el-speaker-grid-3 row">
		<?php if ( $query->have_posts() ) :?>
			<?php while ( $query->have_posts() ) : $query->the_post();?>
				<?php
				$id            = get_the_id();
				$designation   = get_post_meta( $id, "{$cpt}_speaker_designation", true );
				$socials       = get_post_meta( $id, "{$cpt}_speaker_social", true );
				$social_fields = Helper::speakers_socials();
				$content = Helper::get_current_post_content();
				$content = wp_trim_words( $content, $data['count'] );
				$content = "<p>$content</p>";
				?>				
				<div class="rtin-item <?php echo esc_attr( $col_class );?>">
					<div class="speaker-layout4">                        
					
						<div class="speaker-layout4-top">   
							<div class="speaker-layout4-img">                        
							    <?php
								if ( has_post_thumbnail() ){
									the_post_thumbnail( $thumb_size );
								}
								else {
									if ( !empty( RDTheme::$options['no_preview_image']['id'] ) ) {
										echo wp_get_attachment_image( RDTheme::$options['no_preview_image']['id'], $thumb_size );
									}
									else {
										echo '<img class="wp-post-image img-fluid rounded-circle" src="' . Helper::get_img( 'noimage_430x430.jpg' ) . '" alt="'.get_the_title().'">';
									}
								}
								?>
							</div>
						</div>

                        <div class="item-title">
                            <h3 class="title">
                              <?php if ( !empty($data['title_link_display'] ) ): ?>
				           			<a href="<?php the_permalink();?>"><?php the_title();?></a>
				           	<?php endif; ?>
				           	<?php if ( empty($data['title_link_display'] ) ): ?>
				           			<?php the_title();?>
				           	<?php endif; ?>
                            </h3>
							<?php if ( !empty( $data['designation_display'] ) ): ?>
							<div class="designation"><?php echo esc_attr( $designation );?></div>
							<?php endif; ?>                       
                       
                        </div>
                         <?php if ( !empty($data['social_display'] ) ): ?>
                        <div class="item-social">
                            <ul class="social-icons icon-circle icon-rotate">
								<?php foreach ( $socials as $key => $social ): ?>
									<?php if ( !empty( $social ) ): ?>
										<li><a target="_blank" href="<?php echo esc_url( $social );?>"><i class="fa <?php echo esc_attr( $social_fields[$key]['icon'] );?>" aria-hidden="true"></i></a></li>
									<?php endif; ?>
								<?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
				</div>				
			<?php endwhile;?>
		<?php endif;?>
		<?php Helper::wp_reset_temp_query( $temp );?>
	</div>