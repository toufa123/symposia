<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

$btn = $attr = '';

if ( !empty( $data['buttonurl']['url'] ) ) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( !empty( $data['buttontext'] ) ) {
	$btn = '<a class="btn-fill color-yellow border-radius-5 size-lg gust" ' . $attr . '>' . $data['buttontext'] . '</a>';
}
?>
<div class="rt-el-twt-2 rtin-<?php echo esc_attr( $data['style'] );?>">
	<?php if($data['title']){ ?>
		<h2 class="rtin-title <?php echo wp_kses_post( $data['title_style'] );?>"><?php echo wp_kses_post( $data['title'] );?></h2>
	<?php } ?>
	<div class="rtin-content"><?php echo wp_kses_post( $data['content'] );?></div>
	<?php if ( $btn ): ?>
		<div class="rtin-button"><?php echo wp_kses_post( $btn );?></div>		
	<?php endif; ?>
</div>