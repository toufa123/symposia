<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use \WP_Query;
use radiustheme\Eventalk\RDTheme;
use radiustheme\Eventalk\Helper;
$prefix      = EVENTALK_CORE_THEME_PREFIX;
$cpt         = EVENTALK_CORE_CPT_PREFIX;
$thumb_size  = "{$prefix}-size4";
$args = array(
	'post_type'         => "{$cpt}_event",
    'p'                 => $data['event_id'],
	'posts_per_page'    => 1,
    'post_status'       => 'publish'
);
$query = new WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
?>
 <div class="schedule-wrp4 schedule-layout-wrp">
	<?php if ( $query->have_posts() ) :?>
		<?php while ( $query->have_posts() ) : $query->the_post();?>
			<?php
			$id                 = get_the_id();
            $_event_start_date  = get_post_meta( $id, "{$cpt}_event_start_date", true );
            $_event_start_time  = get_post_meta( $id, "{$cpt}_event_start_time", true );
            $_event_end_date    = get_post_meta( $id, "{$cpt}_event_end_date", true );
            $_event_end_time    = get_post_meta( $id, "{$cpt}_event_end_time", true );
            $_event_location    = get_post_meta( $id, "{$cpt}_event_location", true );
            $_event_lat         = get_post_meta( $id, "{$cpt}_event_lat", true );
            $_event_lan         = get_post_meta( $id, "{$cpt}_event_lan", true );
            $_event_ext_link    = get_post_meta( $id, "{$cpt}_event_ext_link", true );
            $schedules 			= get_post_meta($id, 'eventalk_event_schedule', true);
       		$buttontext 		= $data['buttontext'];
            $buttonurl  		= $data['buttonurl'];  
            $socials            = get_post_meta($id, "{$cpt}_event_social", true );
            $socials            = array_filter($socials);
            $social_fields      = Helper::event_socials(); ?>
    <?php 
     if(!empty($schedules)){ ?>
       <div class="row no-gutters full-width"> 
            <?php
                foreach ($schedules as $schedule) {                       
                $image_attributes = wp_get_attachment_image_src($schedule['session_img'], $thumb_size );  
            ?>
               <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6">
		         <div class="schedule-layout4 bg-common" style="background-image: url('<?php echo esc_attr($image_attributes[0]); ?>');">
		            <div class="item-content zindex-up">
		                <ul>
                            <li>
                                <h3 class="title sp-date title-bold hover-yellow color-light">   
                                     <?php echo date_i18n( $data['date_format'], strtotime($schedule['session_start_date'])); ?>
                                </h3>
                            </li>
                             <li class="s4-title">
                            <h3 class="title sp-name title-medium color-light">
                                <?php  if ($data['event_link']) {  ?>
                                    <a href="<?php the_permalink();?>"><?php echo esc_html($schedule['session_title']); ?></a>
                                <?php  } else { ?>
                                    <?php echo esc_html($schedule['session_title']); ?>
                                <?php  } ?>
                            </h3>
                                <p><?php echo esc_html($schedule['session_start_time']); ?> - <?php echo esc_html($schedule['session_end_time']); ?></p>
                            </li>
                            <li class="s4-speaker">
                             <?php if(!empty($schedule['speaker'])){ ?>
                                <h3 class="title title-medium color-light"><?php echo get_the_title($schedule['speaker'] ) ; ?></h3>
                            <?php } ?>
                           <?php if(!empty($schedule['speaker2'])){ ?>
                                <h3 class="title title-medium color-light"><?php echo get_the_title($schedule['speaker2'] ) ; ?></h3>
                            <?php } ?> 
                            <?php if(!empty($schedule['speaker3'])){ ?>
                                <h3 class="title title-medium color-light"><?php echo get_the_title($schedule['speaker3'] ) ; ?></h3>
                            <?php } ?>
                                <p><?php esc_html_e( 'Speaker', 'eventalk' );?></p>
                            </li>
                             <?php  if($data['hall_address']){ ?>
                                <li class="s4-hall">
                                    <h3 class="title title-medium color-light"><?php esc_html_e( 'Hall', 'eventalk' );?></h3>
                                    <p><?php echo esc_html($schedule['schedule_Hall']); ?></p>
                                </li>
                            <?php } ?>
                        </ul>
		            </div>
		        </div>
		    </div>
    			<?php
            }?>
    </div>
    	<div class="row event-social-wrp">
    		<?php if($buttonurl): ?>               
    		  <div class="col-xl-12 text-center"> 
    		    <a href="<?php echo esc_url($buttonurl);?>" title="<?php echo esc_html($buttontext);?>" class="loadmore-four-item btn-fill border-radius-5 size-lg color-yellow"><?php echo esc_html( $buttontext);?></a>
    		</div>                 
    		<?php endif; ?>
    		
    	</div> 
        <?php } 
    endwhile;?>
    <?php endif;?>
    <?php Helper::wp_reset_temp_query( $temp );?>
 </div>





                    