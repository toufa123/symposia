<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
use radiustheme\Eventalk\Helper;

$slides = array();
$default_img = Helper::get_img( 'noslider.jpg' );

foreach ( $data['slides'] as $slide ) {
	$slides[] = array(
		'id'           		 => 'slide-' . time().rand( 1, 99 ),
		'image'        		 => $slide['image']['url'] ? $slide['image']['url'] : $default_img,
		'title'        		 => $slide['title'],
		'title_color'        => $slide['title_color'],
		'subtitle'     			=> $slide['subtitle'],
		'subtitle_mob' 			=> $slide['subtitle_mob'],
		'subtitle_color'        => $slide['subtitle_color'],
		'buttontext'   			=> $slide['buttontext'],
		'buttonurl'    			=> $slide['buttonurl'],
		'slider_alignment'    	=> $slide['slider_alignment'],
	);
}
$slideclass = 'rtin-odd';
?>
<div class="rt-el-slider slider-area">
	<div class="rt-nivoslider overlay-slider">
		<?php foreach ( $slides as $slide ): ?>
			<img src="<?php echo esc_url( $slide['image'] );?>" alt="<?php echo wp_kses_post( $slide['title'] );?>" title="#<?php echo esc_attr( $slide['id'] );?>" />
		<?php endforeach; ?>
	</div>
	<?php foreach ( $slides as $slide ): ?>
		<div id="<?php echo esc_attr( $slide['id'] );?>" class="slider-direction">
			<div class="rtin-content <?php echo esc_attr( $slideclass );?>">
				<div class="rtin-content-inner slide-1">
					<div class="rtin-content-wrap <?php echo esc_html( $slide['slider_alignment'] );?>">
						<?php if ( $slide['title'] ): ?>
							<p class="rtin-title <?php echo esc_html( $slide['title_color'] );?>"><?php echo wp_kses_post( $slide['title'] );?></p>
						<?php endif; ?>
						<?php if ( $slide['subtitle'] ): ?>
							<p class="rtin-subtitle <?php echo esc_html( $slide['subtitle_color'] );?>"><?php echo wp_kses_post( $slide['subtitle'] );?></p>
						<?php endif; ?>
						<?php if ( $slide['subtitle_mob'] ): ?>
							<p class="rtin-subtitle-mob <?php echo esc_html( $slide['subtitle_color'] );?>"><?php echo wp_kses_post( $slide['subtitle_mob'] );?></p>
						<?php endif; ?>
						<?php if ( $slide['buttontext'] ): ?>
							<div class="rtin-btn slider-btn-area forth-line"><a href="<?php echo esc_url( $slide['buttonurl'] );?>" class="btn-ghost color-yellow border-radius-5"><?php echo esc_html( $slide['buttontext'] );?> &nbsp; <i class="fa fa-angle-right" aria-hidden="true"></i></a></div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php $slideclass = ( $slideclass == 'rtin-odd' ) ? 'rtin-even' : 'rtin-odd';?>
	<?php endforeach; ?>
</div>