<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use radiustheme\Roofit\Helper;


if ( ! defined( 'ABSPATH' ) ) exit;
class Video_With_Title extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Video With Title', 'eventalk-core' );
		$this->rt_base = 'rt-video-with-title';
		parent::__construct( $data, $args );
	}
	private function rt_load_scripts(){
		wp_enqueue_script( 'magnific-popup' );	
		wp_enqueue_style( 'magnific-popup' );	
	}
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'layout',
				'label'   => esc_html__( 'Layout', 'eventalk-core' ),
				'options' => array(
					'layout1' => esc_html__( 'Layout 1', 'eventalk-core' ),
					'layout2' => esc_html__( 'Layout 2', 'eventalk-core' ),
					'layout3' => esc_html__( 'Layout 3', 'eventalk-core' ),
					'layout4' => esc_html__( 'Layout 4', 'eventalk-core' ),
					'layout5' => esc_html__( 'Layout 5', 'eventalk-core' ),
				),
				'default' => 'layout1',
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'    => 'image',
				'label'   => esc_html__( 'Image', 'eventalk-core' ),
				'description' => esc_html__( 'Image size should be 1920x820 px', 'eventalk-core' ),
				'condition'   => array( 'layout' => array( 'layout1' ,'layout2','layout3','layout4') ),
			),
			array(
				'type'    => Controls_Manager::URL,
				'id'      => 'videourl',
				'label'   => esc_html__( 'video URL', 'eventalk-core' ),
				'placeholder' => 'http://www.youtube.com/watch?v=1iIZeIy7TqM',
			),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'videobtntext',
				'label'   => esc_html__( 'Watch Now Text', 'eventalk-core' ),
				'default' => 'Watch Now',
				'condition'   => array( 'layout' => array( 'layout5' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'eventalk-core' ),
				'default' => 'Lorem Ipsum Dummy Text',
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'subtitle',
				'label'   => esc_html__( 'Sub Title', 'eventalk-core' ),
				'default' => 'Trailer',
				'condition'   => array( 'layout' => array( 'layout1' ,'layout2','layout5') ),
			),
			array(
				'type'    => Controls_Manager::WYSIWYG,
				'id'      => 'content',
				'label'   => esc_html__( 'Content', 'eventalk-core' ),
				'default' => 'Lorem Ipsum has been the industrys standard dummy text ever since printer took a galley. Rimply dummy text of the printing and typesetting industry',
				'condition'   => array( 'layout' => array( 'layout1' ,'layout2',  'layout4' ,  'layout5' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'eventalk-core' ),
				'default' => 'LOREM IPSUM',
				'condition'   => array( 'layout' => array( 'layout1' ,'layout2','layout4' ) ),
			),
			array(
				'type'    => Controls_Manager::URL,
				'id'      => 'buttonurl',
				'label'   => esc_html__( 'Button URL', 'eventalk-core' ),
				'placeholder' => 'https://your-link.com',
				'condition'   => array( 'layout' => array( 'layout1' ,'layout2', 'layout4' ) ),
			),
			array(
                'mode' => 'section_end',
            ), 

			   // Before Title style
                array(
                    'mode'    => 'section_start',
                    'id'      => 'sec_title_style',
                    'label'   => esc_html__( 'Title', 'eventalk-core' ),
                    'tab'     => Controls_Manager::TAB_STYLE,
                    'condition'   => array( 'layout' => array( 'layout5')),
                ),         

                    array(
                        'type'    => Controls_Manager::COLOR,
                        'id'      => 'title_color',
                        'label'   => __( 'Color', 'eventalk-core' ),
                        'default' => '',                       
                        'selectors' => array(
                                '{{WRAPPER}} .v-title-7' => 'color: {{VALUE}}',                           
                            ),
                    ),  
                    array( 
                        'mode'      => 'group',
                        'type'      => Group_Control_Typography::get_type(),
                        'name'      => 'titles_font_size',                
                        'label'     => esc_html__( 'Icon Typography', 'eventalk-core' ),
                        'selector'  => '{{WRAPPER}} .v-title-7',
                    ),
                    array(
                        'type'    => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'id'      => 'title_padding',
                         'mode'          => 'responsive',
                        'label'   => __( 'Padding', 'eventalk-core' ),
                        'selectors' => array(
                            '{{WRAPPER}} .v-title-7' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                   
                        ),
                        'separator' => 'before',
                    ),  
                    array(
                        'type'    => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                         'mode'          => 'responsive',
                        'id'      => 'title_margin',
                        'label'   => __( 'Margin', 'eventalk-core' ),                 
                        'selectors' => array(
                            '{{WRAPPER}} .v-title-7' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                    
                        ),

                        'separator' => 'before',
                    ),  

            array(
                'mode' => 'section_end',
            ),

              // Before Title style
                array(
                    'mode'    => 'section_start',
                    'id'      => 'sec_content_style',
                    'label'   => esc_html__( 'Content', 'eventalk-core' ),
                    'tab'     => Controls_Manager::TAB_STYLE,
                    'condition'   => array( 'layout' => array( 'layout5')),
                ),         

                    array(
                        'type'    => Controls_Manager::COLOR,
                        'id'      => 'content_color',
                        'label'   => __( 'Color', 'eventalk-core' ),
                        'default' => '',                       
                        'selectors' => array(
                                '{{WRAPPER}} .v-content' => 'color: {{VALUE}}',                           
                            ),
                    ),  
                    array( 
                        'mode'      => 'group',
                        'type'      => Group_Control_Typography::get_type(),
                        'name'      => 'v_content_font_size',                
                        'label'     => esc_html__( 'Icon Typography', 'eventalk-core' ),
                        'selector'  => '{{WRAPPER}} .v-content',
                    ),
                    array(
                        'type'    => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'id'      => 'content_padding',
                         'mode'          => 'responsive',
                        'label'   => __( 'Padding', 'eventalk-core' ),
                        'selectors' => array(
                            '{{WRAPPER}} .v-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                   
                        ),
                        'separator' => 'before',
                    ),  
                    array(
                        'type'    => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                         'mode'          => 'responsive',
                        'id'      => 'content_margin',
                        'label'   => __( 'Margin', 'eventalk-core' ),                 
                        'selectors' => array(
                            '{{WRAPPER}} .v-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                    
                        ),

                        'separator' => 'before',
                    ),  

            array(
                'mode' => 'section_end',
            ),

             
		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();
		$this->rt_load_scripts();
		switch ( $data['layout'] ) {
			case 'layout2':
				$template = 'video-with-title-2';
			break;
			case 'layout3':
				$template = 'video-with-title-3';
			break;
			case 'layout4':
				$template = 'video-with-title-4';
			break;
			case 'layout5':
				$template = 'video-with-title-5';
			break;
			default:
				$template = 'video-with-title-1';
			break;
			}
		return $this->rt_template( $template, $data );
	}
}