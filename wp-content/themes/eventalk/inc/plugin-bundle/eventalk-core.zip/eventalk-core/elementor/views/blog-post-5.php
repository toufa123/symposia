<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Eventalk_Core;
use \WP_Query;
use radiustheme\Eventalk\RDTheme;
use radiustheme\Eventalk\Helper;


$thumb_size_s = EVENTALK_CORE_THEME_PREFIX . '-size9';
$thumb_size_l = EVENTALK_CORE_THEME_PREFIX . '-size8';

$args = array(
	'posts_per_page' => $data['number'],
	'cat'            => (int) $data['cat'],
	'orderby'        => $data['orderby'],
);
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}


$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-xs-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
$i = 1;

?>
<div class="rt-el-blgo-post row">
	<?php if ( $query->have_posts() ) :?>
			<?php while ( $query->have_posts() ) : $query->the_post();?>
				<?php
				$content = Helper::get_current_post_content();
				$content = wp_trim_words( $content, $data['count'] );
				$content = "<p>$content</p>";
				$comments_number = number_format_i18n( get_comments_number() );
				$comments_html   = $comments_number < 2 ? esc_html__( 'Comment' , 'eventalk-core' ) : esc_html__( 'Comments' , 'eventalk-core' );
				$comments_html  .= ': '. $comments_number;
			
				$has_entry_meta_1  = RDTheme::$options['blog_date'] || ( RDTheme::$options['blog_cats'] && has_category() ) ? true : false;
				$has_entry_meta_2  = RDTheme::$options['blog_author_name'] || RDTheme::$options['blog_comment_num'] ? true : false;


				?>
			<?php if ( $i == 1 ) { ?>
			<div class="blog-posts blog-posts col-lg-5">
				<?php
				if ( has_post_thumbnail() ){?>
					<div class="blog-layout5 overlay-gradient thumb-img">
						<?php the_post_thumbnail( $thumb_size_l ); ?>				
							<div class="item-content">
								<div class="item-date-wrap">
								<?php if ( $data['meta']  == 'yes' ): ?>							
									<?php if ( RDTheme::$options['blog_date'] ): ?>
									 	<div class="item-date">
									 		<span class="date-post-7"><?php the_time( 'j' );?></span>
									 		<span class="month-post-7"><?php the_time( 'F' );?></span>
									 		
									 	</div>
									<?php endif; ?>		
								<?php endif ?>		        
								</div>

								<div class="item-title">
								    <h3 class="title-medium color-light hover-yellow">
								         <a href="<?php the_permalink();?>"><?php the_title();?></a>
								    </h3>
								</div>
									<?php if ( $has_entry_meta_2 ): ?>
										<ul class="entry-meta-2">
										
											<li class="vcard-author"><i class="fa fa-tag"></i> 
												<span class="vcat">
												<?php Helper::eventalk_category_prepare();?></span>
											</li>								
																			
											<li class="vcard-comments"> 
												<i class="fa fa-comments" aria-hidden="true"></i> 
												<?php echo wp_kses_post( $comments_number );?>
											</li>

											
										</ul>
									<?php endif; ?>
							</div>
						</div>			
					<?php	} else { ?>					
					<div class="blog-layout3 no-img">				
						<div class="item-date-wrap">
						<?php if ( $data['meta']  == 'yes' ): ?>							
							<?php if ( RDTheme::$options['blog_date'] ): ?>
							 	<div class="item-date"><?php the_time( get_option( 'date_format' ) );?></div>
							<?php endif; ?>		
						<?php endif ?>		        
						</div>
					<div class="item-content">
						<div class="item-title">
						    <h3 class="title-medium color-light hover-yellow">
						         <a href="<?php the_permalink();?>"><?php the_title();?></a>
						    </h3>
						</div>
						<?php if ( $has_entry_meta_2 ): ?>
							<ul class="entry-meta-2">
							
								<li class="vcard-author"><i class="fa fa-tag"></i> 
									<span class="vcat">
									<?php Helper::eventalk_category_prepare();?></span>
								</li>								
																
								<li class="vcard-comments"> 
									<i class="fa fa-comments" aria-hidden="true"></i> 
									<?php echo wp_kses_post( $comments_number );?>
								</li>

								
							</ul>
						<?php endif; ?>
					</div>
				</div>		
				<?php	} ?>
			</div>
		<?php } ?>
		
		<?php if ( $i == 2 ) { ?>
		<div class="col-lg-7">
	        <div class="row rtblog-content">
		<?php } ?>	
			<?php if ( $i > 1 & $i < 6 ) { ?>
			<div class="blog-posts blog-posts col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<?php
			if ( has_post_thumbnail() ){?>
				<div class="blog-layout5 overlay-gradient thumb-img">
					<?php the_post_thumbnail( $thumb_size_s ); ?>				
						<div class="item-content">
							<div class="item-date-wrap">
							<?php if ( $data['meta']  == 'yes' ): ?>							
								<?php if ( RDTheme::$options['blog_date'] ): ?>
								 	<div class="item-date">
								 		<span class="date-post-7"><?php the_time( 'j' );?></span>
								 		<span class="month-post-7"><?php the_time( 'F' );?></span>
								 		
								 	</div>
								<?php endif; ?>		
							<?php endif ?>		        
							</div>

							<div class="item-title">
							    <h3 class="title-medium color-light hover-yellow">
							         <a href="<?php the_permalink();?>"><?php the_title();?></a>
							    </h3>
							</div>
								<?php if ( $has_entry_meta_2 ): ?>
									<ul class="entry-meta-2">									
										<li class="vcard-author"><i class="fa fa-tag"></i> 
											<span class="vcat">
											<?php Helper::eventalk_category_prepare();?></span>
										</li>								
																		
										<li class="vcard-comments"> 
											<i class="fa fa-comments" aria-hidden="true"></i> 
											<?php echo wp_kses_post( $comments_number );?>
										</li>
										
									</ul>
								<?php endif; ?>
								</div>
									</div>			
									<?php	} else { ?>					
									<div class="blog-layout3 no-img">				
										<div class="item-date-wrap">
										<?php if ( $data['meta']  == 'yes' ): ?>							
											<?php if ( RDTheme::$options['blog_date'] ): ?>
											 	<div class="item-date"><?php the_time( get_option( 'date_format' ) );?></div>
											<?php endif; ?>		
										<?php endif ?>		        
										</div>
									<div class="item-content">
										<div class="item-title">
										    <h3 class="title-medium color-light hover-yellow">
										         <a href="<?php the_permalink();?>"><?php the_title();?></a>
										    </h3>
										</div>
										
									</div>
									</div>		
									<?php	} ?>
								</div>
								<?php } ?>	

							<?php if ( $i == 5 ) { ?>
							</div>
						</div>
					<?php } ?>
				<?php if ( $i > 5 ) { ?>
               <div class="blog-posts blog-posts col-lg-4">
				<?php
				if ( has_post_thumbnail() ){?>
				<div class="blog-layout5 overlay-gradient thumb-img">
				<?php the_post_thumbnail( $thumb_size_s ); ?>				
				<div class="item-content">
				<div class="item-date-wrap">
				<?php if ( $data['meta']  == 'yes' ): ?>							
					<?php if ( RDTheme::$options['blog_date'] ): ?>
					 	<div class="item-date">
					 		<span class="date-post-7"><?php the_time( 'j' );?></span>
					 		<span class="month-post-7"><?php the_time( 'F' );?></span>
					 		
					 	</div>
					<?php endif; ?>		
				<?php endif ?>		        
				</div>

				<div class="item-title">
				    <h3 class="title-medium color-light hover-yellow">
				         <a href="<?php the_permalink();?>"><?php the_title();?></a>
				    </h3>
				</div>
					<?php if ( $has_entry_meta_2 ): ?>
						<ul class="entry-meta-2">									
							<li class="vcard-author"><i class="fa fa-tag"></i> 
								<span class="vcat">
								<?php Helper::eventalk_category_prepare();?></span>
							</li>								
															
							<li class="vcard-comments"> 
								<i class="fa fa-comments" aria-hidden="true"></i> 
								<?php echo wp_kses_post( $comments_number );?>
							</li>
							
						</ul>
					<?php endif; ?>
					</div>
						</div>			
						<?php	} else { ?>					
						<div class="blog-layout3 no-img">				
							<div class="item-date-wrap">
							<?php if ( $data['meta']  == 'yes' ): ?>							
								<?php if ( RDTheme::$options['blog_date'] ): ?>
								 	<div class="item-date"><?php the_time( get_option( 'date_format' ) );?></div>
								<?php endif; ?>		
							<?php endif ?>		        
							</div>
						<div class="item-content">
							<div class="item-title">
							    <h3 class="title-medium color-light hover-yellow">
							         <a href="<?php the_permalink();?>"><?php the_title();?></a>
							    </h3>
							</div>
							
						</div>
						</div>		
						<?php	} ?>
					</div>

				<?php } ?>
			<?php if ( $query->post_count == $i ) { ?>							

				<?php } ?>
			<?php $i++;  ?>		

		<?php endwhile;?>
	<?php endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>
</div>