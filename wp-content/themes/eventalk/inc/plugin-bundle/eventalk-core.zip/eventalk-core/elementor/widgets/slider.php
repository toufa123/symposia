<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use Elementor\Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;
class Slider extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'FullScreen Slider', 'eventalk-core' );
		$this->rt_base = 'rt-slider';
		parent::__construct( $data, $args );
	}
	private function rt_load_scripts(){
		wp_enqueue_style(  'nivo-slider' );
		wp_enqueue_script( 'nivo-slider' );			
	}
	private function rt_load_scripts2(){
		wp_enqueue_style(  'nivo-slider' );
		wp_enqueue_script( 'nivo-slider' );
		wp_enqueue_script( 'countdown' );	
	}
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'eventalk-core' ),

			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'layout',
				'label'   => esc_html__( 'Layout', 'eventalk-core' ),
				'options' => array(
					'layout1' => esc_html__( 'Layout 1', 'eventalk-core' ),
					'layout2' => esc_html__( 'Layout 2', 'eventalk-core' ),					
					'layout3' => esc_html__( 'Layout 3', 'eventalk-core' ),					
				),
				'default' => 'layout1',
			),		
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'slides2',
				'label'   => esc_html__( 'Add as many slides as you want', 'eventalk-core' ),
				'condition'   => array( 'layout' => array( 'layout2') ),
				'fields'  => array(
					array(
						'type'    => Controls_Manager::MEDIA,
						'name'    => 'image',
						'label'   => esc_html__( 'Image', 'eventalk-core' ),
						'description' => esc_html__( 'Image size should be 1920x820 px', 'eventalk-core' ),
					),
									
				),
			),
			
			array(
				'type'    => Controls_Manager::TEXT,
				'id'    => 'title',
				'label'   => esc_html__( 'Title', 'eventalk-core' ),
				'default' => 'Marketing Conferencee 2018',
				'condition'   => array( 'layout' => array( 'layout2') ),
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'    => 'subtitle',
				'label'   => esc_html__( 'Subtitle', 'eventalk-core' ),
				'default' => '17 - 25 December 2018 Tobacco Dock, London ',
				'condition'   => array( 'layout' => array( 'layout2') ),
			),
			array(
				'type' => Controls_Manager::DATE_TIME,
				'id'      => 'countdown',
				'label'   => esc_html__( 'Event Date Time', 'eventalk-core' ),
				'default' => 2018,
				'condition'   => array( 'layout' => array( 'layout2') ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'eventalk-core' ),
				'default' => 'Buy Tickets Now!',
				'condition'   => array( 'layout' => array( 'layout2') ),
			),
			array(
				'type'    => Controls_Manager::URL,
				'id'      => 'buttonurl',
				'label'   => esc_html__( 'Button URL', 'eventalk-core' ),
				'placeholder' => 'https://your-link.com',
				'condition'   => array( 'layout' => array( 'layout2') ),
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'slides',
				'label'   => esc_html__( 'Add as many slides as you want', 'eventalk-core' ),
				'condition'   => array( 'layout' => array( 'layout1','layout3') ),
				'fields'  => array(
					array(
						'type'    => Controls_Manager::MEDIA,
						'name'    => 'image',
						'label'   => esc_html__( 'Image', 'eventalk-core' ),
						'description' => esc_html__( 'Image size should be 1920x820 px', 'eventalk-core' ),
					),
					array(
						'type'    => Controls_Manager::TEXT,
						'name'    => 'title',
						'label'   => esc_html__( 'Title', 'eventalk-core' ),
						'default' => 'LOREM IPSUM DUMMY TEXT',
					),
					array(
						'type'    => Controls_Manager::SELECT2,
						'name'      => 'title_color',
						'label'   => esc_html__( 'Title Color', 'eventalk-core' ),
						'options' => array(
							'light' 	=> esc_html__( 'Light Color', 'eventalk-core' ),
							'dark'  	=> esc_html__( 'Dark Color', 'eventalk-core' ),
							'primary'   => esc_html__( 'Primary Color', 'eventalk-core' ),
					),
						'default' => 'light',
					),
					array(
						'type'    => Controls_Manager::TEXTAREA,
						'name'    => 'subtitle',
						'label'   => esc_html__( 'Subtitle(For desktop and tab)', 'eventalk-core' ),
						'default' => 'Dorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod teididunt ut labore et orem ipsum dolor sit ameo eiusmod tm do eiusmod teididunt ut labore et dolore',
					),

					array(
						'type'    => Controls_Manager::TEXTAREA,
						'name'    => 'subtitle_mob',
						'label'   => esc_html__( 'Subtitle(For mobile)', 'eventalk-core' ),
						'default' => 'Dorem ipsum dolor sit amet, consectetur adipisicing',
					),
					array(
						'type'    => Controls_Manager::SELECT2,
						'name'      => 'subtitle_color',
						'label'   => esc_html__( 'Sub Title Color', 'eventalk-core' ),
						'options' => array(
							'light' 	=> esc_html__( 'Light Color', 'eventalk-core' ),
							'dark'  	=> esc_html__( 'Dark Color', 'eventalk-core' ),
							'primary'   => esc_html__( 'Primary Color', 'eventalk-core' ),
					),
						'default' => 'light',
					),

					array(
						'type'    => Controls_Manager::TEXT,
						'name'    => 'buttontext',
						'label'   => esc_html__( 'Button Text', 'eventalk-core' ),
						'default' => 'LOREM IPSUM',
					),
					array(
						'type'    => Controls_Manager::TEXT,
						'name'    => 'buttonurl',
						'label'   => esc_html__( 'Button URL', 'eventalk-core' ),
					),
					array(
						'type'    => Controls_Manager::SELECT2,
						'name'      => 'slider_alignment',
						'label'   => esc_html__( 'Slider Alignment', 'eventalk-core' ),
						'options' => array(
							'text-left' 	=> esc_html__( 'Left', 'eventalk-core' ),
							'text-right'  	=> esc_html__( 'Right', 'eventalk-core' ),
							'text-center'   => esc_html__( 'Center', 'eventalk-core' ),
					),
						'default' => 'text-center',
					),				
				),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();
		switch ( $data['layout'] ) {
			case 'layout2':
				$this->rt_load_scripts2();	
				$template = 'slider-2';
			break;	
			case 'layout3':
				$this->rt_load_scripts2();	
				$template = 'slider-3';
			break;			
			default:
				$this->rt_load_scripts();	
				$template = 'slider-1';
			break;
		}
		return $this->rt_template( $template, $data );
	}
}