<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class Info_Box extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Info Box', 'eventalk-core' );
		$this->rt_base = 'rt-info-box';
		parent::__construct( $data, $args );
	}
	
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'eventalk-core' ),
				'options' => array(
					'style1' => esc_html__( 'Style 1', 'eventalk-core' ),
					'style2' => esc_html__( 'Style 2', 'eventalk-core' ),
					'style3' => esc_html__( 'Style 3', 'eventalk-core' ),
					'style4' => esc_html__( 'Style 4', 'eventalk-core' ),
					'style5' => esc_html__( 'Style 5', 'eventalk-core' ),
					'style6' => esc_html__( 'Style 6', 'eventalk-core' ),
					'style7' => esc_html__( 'Style 7', 'eventalk-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'theme',
				'label'   => esc_html__( 'Theme', 'eventalk-core' ),
				'options' => array(
					'light' => esc_html__( 'Light Background', 'eventalk-core' ),
					'dark'  => esc_html__( 'Dark Background', 'eventalk-core' ),
					'primary'  => esc_html__( 'Primary Background', 'eventalk-core' ),
				),
				'default' => 'light',
				'condition'   => array( 'style' => array( 'style1','style5' ,'style6') ),
			),
			
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'icontype',
				'label'   => esc_html__( 'Icon Type', 'eventalk-core' ),
				'options' => array(
					'icon'  => esc_html__( 'Icon', 'eventalk-core' ),
					'image' => esc_html__( 'Custom Image', 'eventalk-core' ),
				),
				'default' => 'icon',
				'condition'   => array( 'style' => array( 'style1', 'style2' ,'style5', 'style7') ),
			),
			array(
				'type'    => Controls_Manager::ICON,
				'id'      => 'icon',
				'label'   => esc_html__( 'Icon', 'eventalk-core' ),
				'default' => 'fa fa-university',
				'condition'   => array( 'style' => array( 'style1', 'style2','style5' ,'style7' ), 'icontype' => array( 'icon' ) ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'image',
				'label'   => esc_html__( 'Image', 'eventalk-core' ),
				'condition'   => array( 'style' => array( 'style1', 'style2','style5', 'style7' ), 'icontype' => array( 'image' ) ),
				'description' => esc_html__( 'Recommended image size is 67x67 px', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'image-alt',
				'label'   => esc_html__( 'Image', 'eventalk-core' ),
				'condition'   => array( 'style' => array( 'style3', 'style4', 'style6'  ) ),
			),
            array(
                    'type'    => Controls_Manager::SELECT2,
                    'id'      => 'icon_color',
                    'label'   => esc_html__( 'Icon Color', 'eventalk-core' ),
                    'options' => array(
                            'primaryColor'  => esc_html__( 'Primary Color', 'eventalk-core' ),
                            'secondaryColor' => esc_html__( 'Secondary Color', 'eventalk-core' ),
                            'colorGreen'  => esc_html__( 'Accent Color', 'eventalk-core' ),					
                    ),
                    'default' 		=> 'primaryColor',
                    'condition'     => array( 'icontype' => array( 'icon' ),'style' => array( 'style2' ) ),
                ),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'eventalk-core' ),
				'default' => 'Lorem Ipsum',
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'content',
				'label'   => esc_html__( 'Content', 'eventalk-core' ),
				'default' => 'Lorem Ipsum hasbeen standard daand scrambled. Rimply dummy text of the printing and typesetting industry',
			),
			array(
				'type'  => Controls_Manager::URL,
				'id'    => 'url',
				'label' => esc_html__( 'Link (Optional)', 'eventalk-core' ),
				'placeholder' => 'https://your-link.com',
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();	

		switch ( $data['style'] ) {
		case 'style2':			
			$template = 'info-box-2';
		break;	
		case 'style3':			
			$template = 'info-box-3';
		break;			
		case 'style4':			
			$template = 'info-box-4';
		break;	
		case 'style5':			
			$template = 'info-box-5';
		break;		
		case 'style6':			
			$template = 'info-box-6';
		break;		
		case 'style7':			
			$template = 'info-box-7';
		break;			
		default:			
			$template = 'info-box-1';
		break;
		}

		return $this->rt_template( $template, $data );
	}
}