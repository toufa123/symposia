<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use Elementor\Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;
class Price_Plan extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Price & Plan', 'eventalk-core' );
		$this->rt_base = 'rt-price-plan';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'eventalk-core' ),
			),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'layout',
                'label'   => esc_html__( 'Layout', 'eventalk-core' ),
                'options' => array(
                        'layout1' => esc_html__( 'Layout 1', 'eventalk-core' ),
                        'layout2' => esc_html__( 'Layout 2', 'eventalk-core' ),
                        'layout3' => esc_html__( 'Layout 3', 'eventalk-core' ),					
                        'layout4' => esc_html__( 'Layout 4', 'eventalk-core' ),					
                        'layout5' => esc_html__( 'Layout 5', 'eventalk-core' ),					
                ),
                'default' => 'layout1',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'eventalk-core' ),
				'default' => 'Personal Plan',
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'price',
				'label'   => esc_html__( 'Price', 'eventalk-core' ),
				'default' => 49,
				'description' => esc_html__( 'Maximum number of words', 'eventalk-core' ),				
			),
                    array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'period',
				'label'   => esc_html__( 'Period', 'eventalk-core' ),
                                'condition'   => array( 'layout' => array( 'layout3','layout4')),
				'default' => 'mo',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'currency',
				'label'   => esc_html__( 'Currency', 'eventalk-core' ),
				'default' => '$',
				'description' => esc_html__( 'Select Currency', 'eventalk-core' ),				
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'st_content',
				'label'   => esc_html__( 'Content', 'eventalk-core' ),
				'default' => 'How you transform your business as technology, consumer, habits industrys dynamic',
				 'condition'   => array( 'layout' => array( 'layout5')),
			),

			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'options3',
				'label'   => esc_html__( 'Add as many as you want', 'eventalk-core' ),
                  'condition'   => array( 'layout' => array( 'layout3')),
				'fields'  => array(					
					array(
						'type'    => Controls_Manager::TEXT,
						'name'    => 'option_title',
						'label'   => esc_html__( 'Options', 'eventalk-core' ),
						'default' => 'Dorem ipsum dolor',
					),
                    array(
                        'type'    => Controls_Manager::ICON,
                        'name'      => 'icon',
                        'label'   => esc_html__( 'Icon', 'eventalk-core' ),
                        'default' => 'fa fa-check',                                           
                    ),
				),				
			),
              array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'options',
				'label'   => esc_html__( 'Add as many slides as you want', 'eventalk-core' ),
                                'condition'   => array( 'layout' => array( 'layout1','layout2','layout4' )),
				'fields'  => array(					
					array(
						'type'    => Controls_Manager::TEXT,
						'name'    => 'option_title',
						'label'   => esc_html__( 'Options', 'eventalk-core' ),
						'default' => 'Dorem ipsum dolor',
					),    
					array(
						'type'        => Controls_Manager::SWITCHER,
						'name'          => 'option_select_loop',
						'label'       => esc_html__( 'Feature yes or no', 'eventalk-core' ),
						'label_on'    => esc_html__( 'Yes', 'eventalk-core' ),
						'label_off'   => esc_html__( 'No', 'eventalk-core' ),
						'default'     => 'yes',
						'description' => esc_html__( 'Feature Default: Yes', 'eventalk-core' ),
					),                                    
				),				
			),                    
			array(
				'type'    => Controls_Manager::TEXT,
				'id'    => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'eventalk-core' ),
				'default' => 'Buy Ticket',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'    => 'buttonurl',
				'label'   => esc_html__( 'Button URL', 'eventalk-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'button_style',
				'label'   => esc_html__( 'Button Style', 'eventalk-core' ),
				'condition'   => array( 'layout' => array( 'layout1' , 'layout5')),
				'options' => array(
				'style1' => esc_html__( 'Style 1', 'eventalk-core' ),
				'style2' => esc_html__( 'Style 2', 'eventalk-core' ),
				'style3' => esc_html__( 'Style 3', 'eventalk-core' ),
				),
				'default' => 'layout1',
			),				
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();		
                switch ( $data['layout'] ) {
                    case 'layout2':
                        $template = 'price-plan-2';
                    break;
                    case 'layout3':
                        $template = 'price-plan-3';
                    break; 
                    case 'layout4':
                        $template = 'price-plan-4';
                    break; 
                    case 'layout5':
                        $template = 'price-plan-5';
                    break;
                    default:
                        $template = 'price-plan-1';
                    break;
		}                
		return $this->rt_template( $template, $data );
	}
}