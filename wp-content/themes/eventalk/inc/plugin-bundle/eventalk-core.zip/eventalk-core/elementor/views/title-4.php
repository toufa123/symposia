<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
?>
<div class="rt-el-title section-heading <?php echo esc_html( $data['style'] );?>">	
        <h3 class="rtin-title title-bold color-dark title-bar"><?php echo esc_html( $data['title'] );?></h3>	
</div>
