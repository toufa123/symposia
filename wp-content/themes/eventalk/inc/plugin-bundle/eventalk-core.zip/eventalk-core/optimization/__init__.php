<?php 
// Security check
defined('ABSPATH') || die();

require_once('config.php');
require_once('RTOptionFramework.interface.php');
require_once('RTOptimizerHooks.class.php');
require_once('RTCustomizer.class.php');
require_once('RTRedux.class.php');
require_once('RTOptimize.class.php');
require_once('RTOPreload.class.php');
require_once('RTOExcludeScript.class.php');
require_once('RTOjQuery.class.php');
require_once('RTOElementor.class.php');