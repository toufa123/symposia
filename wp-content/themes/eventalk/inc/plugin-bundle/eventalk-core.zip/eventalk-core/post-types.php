<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;

use radiustheme\Eventalk\RDTheme;
use \RT_Posts;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Posts' ) ) {
	return;
}
$prefix = EVENTALK_CORE_CPT_PREFIX;
$eventalk_post_types = array(
	"{$prefix}_speaker"        => array(
		'title'        => esc_html__( 'Speaker', 'eventalk-core' ),
		'plural_title' => esc_html__( 'Speaker', 'eventalk-core' ),
		'menu_icon'    => 'dashicons-businessman',
		'rewrite'      => RDTheme::$options['speakers_slug'],
        'supports'     => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' ),
		),
	"{$prefix}_event"        => array(
		'title'        => esc_html__( 'Event', 'eventalk-core' ),
		'plural_title' => esc_html__( 'Event', 'eventalk-core' ),
		'menu_icon'    => 'dashicons-clipboard',
		'supports'     => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' ),
		'rewrite'      => RDTheme::$options['event_slug'],
		),	
		"{$prefix}_gallrey"   => array(
			'title'           => esc_html__( 'Gallrey', 'eventalk-core' ),
			'plural_title'    => esc_html__( 'Gallrey', 'eventalk-core' ),
			'menu_icon'       => 'dashicons-format-gallery',
			'rewrite'         => RDTheme::$options['gallrey_slug'],
			'supports'        => array( 'title', 'thumbnail', 'editor','excerpt', 'page-attributes' )
		),	
	);

$eventalk_taxonomies = array(
	"{$prefix}_speaker_category" => array(
		'title'        => esc_html__( 'Speaker Category', 'eventalk-core' ),
		'plural_title' => esc_html__( 'Speaker Categories', 'eventalk-core' ),
		'post_types'   => "{$prefix}_speaker",
		),
	"{$prefix}_event_category" => array(
		'title'        => esc_html__( 'Event Category', 'eventalk-core' ),
		'plural_title' => esc_html__( 'Event Categories', 'eventalk-core' ),
		'post_types'   => "{$prefix}_event",
		),
	"{$prefix}_gallrey_category" => array(
		'title'        => esc_html__( 'Gallrey Category', 'eventalk-core' ),
		'plural_title' => esc_html__( 'Gallrey Categories', 'eventalk-core' ),
		'post_types'   => "{$prefix}_gallrey",
		'rewrite'      => array( 'slug' => RDTheme::$options['gallrey_cat_slug'] ),
	),
	
	);

$EVENTALK_Posts = RT_Posts::getInstance();
$EVENTALK_Posts->add_post_types( $eventalk_post_types );
$EVENTALK_Posts->add_taxonomies( $eventalk_taxonomies );