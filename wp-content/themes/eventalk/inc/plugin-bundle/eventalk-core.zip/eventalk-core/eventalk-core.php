<?php
/*
Plugin Name: Eventalk Core
Plugin URI: https://www.radiustheme.com
Description: Eventalk Core Plugin for Eventalk Theme
Version: 1.6.2
Author: RadiusTheme
Author URI: https://www.radiustheme.com
*/
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! defined( 'EVENTALK_CORE' ) ) {
	define( 'EVENTALK_CORE',                   ( WP_DEBUG ) ? time() : '1.0' );
	define( 'EVENTALK_CORE_THEME_PREFIX',      'eventalk' );
	define( 'EVENTALK_CORE_THEME_PREFIX_VAR',  'eventalk' );
	define( 'EVENTALK_CORE_CPT_PREFIX',        'eventalk' );
	define( 'EVENTALK_CORE_DIR', plugin_dir_path( __FILE__ ) );
	define( 'EVENTALK_CORE_UPDATE_1', true );
}
class Eventalk_Core {
	public $plugin  = 'eventalk-core';
	public $action  = 'eventalk_theme_init';
	public function __construct() {
		$prefix = EVENTALK_CORE_THEME_PREFIX_VAR;		
		add_action( 'plugins_loaded', array( $this, 'demo_importer' ), 15 );
		add_action( 'plugins_loaded', array( $this, 'eventalk_core_load_textdomain' ), 16 );
		add_action( 'after_setup_theme', array( $this, 'post_types' ), 15 );
		add_action( 'after_setup_theme', array( $this, 'elementor_widgets' ) );
		// Redux Flash permalink after options changed
		add_action( "redux/options/{$prefix}/saved", array( $this, 'flush_redux_saved' ), 10, 2 );
		add_action( "redux/options/{$prefix}/section/reset", array( $this, 'flush_redux_reset' ) );
		add_action( "redux/options/{$prefix}/reset", array( $this, 'flush_redux_reset' ) );
		add_action( 'init', array( $this, 'rewrite_flush_check' ) );
	}

	public function demo_importer() {
		require_once 'demo-importer.php';
		require_once 'optimization/__init__.php';
	}

	public function eventalk_core_load_textdomain() {
		load_plugin_textdomain( $this->plugin , false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
	}

	public function post_types(){
		if ( !did_action( $this->action ) || ! defined( 'RT_FRAMEWORK_VERSION' ) ) {
			return;
		}
		require_once 'post-types.php';
		require_once 'post-meta.php';
		require_once 'shortcode.php';
		require_once 'widgets/init.php';
	}

	public function elementor_widgets(){
		if ( did_action( $this->action ) && did_action( 'elementor/loaded' ) ) {
			require_once 'elementor/init.php';
		}
	}

	// Flush rewrites
	public function flush_redux_saved( $saved_options, $changed_options ){
		if ( empty( $changed_options ) ) {
			return;
		}
		$prefix = EVENTALK_CORE_THEME_PREFIX_VAR;
		$flush  = false;
		$slugs  = array( 'speaker_slug', 'gallrey_slug' );
		foreach ( $slugs as $slug ) {
			if ( array_key_exists( $slug, $changed_options ) ) {
				$flush = true;
			}
		}

		if ( $flush ) {
			update_option( "{$prefix}_rewrite_flash", true );
		}
	}
	public function flush_redux_reset(){
		$prefix = EVENTALK_CORE_THEME_PREFIX_VAR;
		update_option( "{$prefix}_rewrite_flash", true );
	}
	public function rewrite_flush_check() {
		$prefix = EVENTALK_CORE_THEME_PREFIX_VAR;
		if ( get_option( "{$prefix}_rewrite_flash" ) == true ) {
			flush_rewrite_rules();
			update_option( "{$prefix}_rewrite_flash", false );
		}
	}
}
new Eventalk_Core;