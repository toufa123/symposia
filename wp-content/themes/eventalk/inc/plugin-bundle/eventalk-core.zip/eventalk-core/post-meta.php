<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Eventalk_Core;
use radiustheme\Eventalk\RDTheme;
use radiustheme\Eventalk\Helper;
use \RT_Postmeta;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Postmeta' ) ) {
	return;
}

$EVENTALK_Postmeta = RT_Postmeta::getInstance();
$prefix = EVENTALK_CORE_CPT_PREFIX;
$nav_menus = wp_get_nav_menus( array( 'fields' => 'id=>name' ) );
$nav_menus = array( 'default' => esc_html__( 'Default', 'eventalk-core' ) ) + $nav_menus;
$sidebars  = array( 'default' => esc_html__( 'Default', 'eventalk-core' ) ) + Helper::custom_sidebar_fields();

$EVENTALK_Postmeta->add_meta_box( 'page_settings', esc_html__( 'Layout Settings', 'eventalk-core' ), array( 'page', 'post', "{$prefix}_speaker", "{$prefix}_event" , "{$prefix}_sponsor", "{$prefix}_testimonial"), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_layout" => array(
			'label'   => esc_html__( 'Layout', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default'       => esc_html__( 'Default', 'eventalk-core' ),
				'full-width'    => esc_html__( 'Full Width', 'eventalk-core' ),
				'left-sidebar'  => esc_html__( 'Left Sidebar', 'eventalk-core' ),
				'right-sidebar' => esc_html__( 'Right Sidebar', 'eventalk-core' ),
				),
			'default'  => 'default',
			),			
		"{$prefix}_sidebar" => array(
			'label'    => esc_html__( 'Custom Sidebar', 'eventalk-core' ),
			'type'     => 'select',
			'options'  => $sidebars,
			'default'  => 'default',
			),
		"{$prefix}_page_menu" => array(
			'label'   => esc_html__( 'Main Menu', 'eventalk-core' ),
			'type'    => 'select',
			'options' => $nav_menus,
			'default' => 'default',
			),
		"{$prefix}_tr_header" => array(
			'label'   => esc_html__( 'Transparent Header', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'on'      => esc_html__( 'Enabled', 'eventalk-core' ),
				'off'     => esc_html__( 'Disabled', 'eventalk-core' ),
				),
			'default'  => 'default',
			),		
		"{$prefix}_header" => array(
			'label'   => esc_html__( 'Header Layout', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'1'       => esc_html__( 'Layout 1', 'eventalk-core' ),
				'2'       => esc_html__( 'Layout 2', 'eventalk-core' ),
				'3'       => esc_html__( 'Layout 3', 'eventalk-core' ),
				'4'       => esc_html__( 'Layout 4', 'eventalk-core' ),
				'5'       => esc_html__( 'Layout 5', 'eventalk-core' ),			
				'6'       => esc_html__( 'Layout 6', 'eventalk-core' ),			
				'7'       => esc_html__( 'Layout 7', 'eventalk-core' ),			
				),
			'default'  => 'default',
			),	
		"{$prefix}_footer" => array(
			'label'   => esc_html__( 'Footer Layout', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'1'       => esc_html__( 'Layout 1', 'eventalk-core' ),
				'2'       => esc_html__( 'Layout 2', 'eventalk-core' ),				
				'3'       => esc_html__( 'Layout 3', 'eventalk-core' ),				
				'4'       => esc_html__( 'Layout 4', 'eventalk-core' ),				
				),
			'default'  => 'default',
			),
		"{$prefix}_top_padding" => array(
			'label'   => esc_html__( 'Content Padding Top', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'0px'     => '0px',
				'10px'    => '10px',
				'20px'    => '20px',
				'30px'    => '30px',
				'40px'    => '40px',
				'50px'    => '50px',
				'60px'    => '60px',
				'70px'    => '70px',
				'80px'    => '80px',
				'90px'    => '90px',
				'100px'   => '100px',
				),
			'default'  => 'default',
			),
		"{$prefix}_bottom_padding" => array(
			'label'   => esc_html__( 'Content Padding Bottom', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'0px'     => '0px',
				'10px'    => '10px',
				'20px'    => '20px',
				'30px'    => '30px',
				'40px'    => '40px',
				'50px'    => '50px',
				'60px'    => '60px',
				'70px'    => '70px',
				'80px'    => '80px',
				'90px'    => '90px',
				'100px'   => '100px',
				),
			'default'  => 'default',
			),
		"{$prefix}_banner" => array(
			'label'   => esc_html__( 'Banner', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'on'      => esc_html__( 'Enable', 'eventalk-core' ),
				'off'     => esc_html__( 'Disable', 'eventalk-core' ),
				),
			'default'  => 'default',
			),
		"{$prefix}_breadcrumb" => array(
			'label'   => esc_html__( 'Breadcrumb', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'on'      => esc_html__( 'Enable', 'eventalk-core' ),
				'off'     => esc_html__( 'Disable', 'eventalk-core' ),
				),
			'default'  => 'default',
			),
		"{$prefix}_banner_type" => array(
			'label'   => esc_html__( 'Banner Background Type', 'eventalk-core' ),
			'type'    => 'select',
			'options' => array(
				'default'  => esc_html__( 'Default', 'eventalk-core' ),
				'bgimg'    => esc_html__( 'Background Image', 'eventalk-core' ),
				'bgcolor'  => esc_html__( 'Background Color', 'eventalk-core' ),
				),
			'default'  => 'default',
			),
		"{$prefix}_banner_bgimg" => array(
			'label' => esc_html__( 'Banner Background Image', 'eventalk-core' ),
			'type'  => 'image',
			'desc'  => esc_html__( 'If not selected, default will be used', 'eventalk-core' ),
			),
		"{$prefix}_banner_bgcolor" => array(
			'label' => esc_html__( 'Banner Background Color', 'eventalk-core' ),
			'type'  => 'color_picker',
			'desc'  => esc_html__( 'If not selected, default will be used', 'eventalk-core' ),
			),
		),
	) 
);

/////////////
// Speaker //
/////////////
$eventalk_speaker_social = array(
	'facebook' => array(
		'label' => esc_html__( 'Facebook', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-facebook',
		),
	'twitter' => array(
		'label' => esc_html__( 'Twitter', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-twitter',
		),
	'linkedin' => array(
		'label' => esc_html__( 'Linkedin', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-linkedin',
		),
	'gplus' => array(
		'label' => esc_html__( 'Google Plus', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-google-plus',
		),
	'skype' => array(
		'label' => esc_html__( 'Skype', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-skype',
		),
	'youtube' => array(
		'label' => esc_html__( 'Youtube', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-youtube-play',
		),
	'pinterest' => array(
		'label' => esc_html__( 'Pinterest', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-pinterest-p',
		),
	'instagram' => array(
		'label' => esc_html__( 'Instagram', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-instagram',
		),
	'github' => array(
		'label' => esc_html__( 'Github', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-github',
		),
	'stackoverflow' => array(
		'label' => esc_html__( 'Stackoverflow', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-stack-overflow',
		),
	);

$EVENTALK_Postmeta->add_meta_box( 'speaker_socials', esc_html__( 'speaker Socials', 'eventalk-core' ), array( "{$prefix}_speaker" ), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_speaker_socials_header" => array(
			'label' => esc_html__( 'Socials', 'eventalk-core' ),
			'type'  => 'header',
			'desc'  => esc_html__( 'Put your speakers links here', 'eventalk-core' ),
			),
		"{$prefix}_speaker_social" => array(
			'type'  => 'group',
			'value'  => Helper::speakers_socials()
			),
		)
	)
);

$EVENTALK_Postmeta->add_meta_box( 'speaker_info', esc_html__( 'speaker Information', 'eventalk-core' ), array( "{$prefix}_speaker" ), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_speaker_designation" => array(
			'label' => esc_html__( 'Designation', 'eventalk-core' ),
			'type'  => 'text',
			),			
		"{$prefix}_speaker_other" => array(
			'label' => esc_html__( 'Show Other speaker', 'eventalk-core' ),
			'type'  => 'select',
			'options' => array(				
				'1'    => 'Yes',
				'0'     => 'No',
				),
			'default'  => '1',
			),
		)
	)
);

$EVENTALK_Postmeta->add_meta_box( 'speaker_skills', esc_html__( 'speaker Skills', 'eventalk-core' ), array( "{$prefix}_speaker" ), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_speaker_skill" => array(
			'type'  => 'repeater',
			'button' => esc_html__( 'Add New Skill', 'eventalk-core' ),
			'value'  => array(
				'skill_name' => array(
					'label' => esc_html__( 'Skill Name', 'eventalk-core' ),
					'type'  => 'text',
					'desc'  => esc_html__( 'eg. Recipes', 'eventalk-core' ),
					),
				'skill_value' => array(
					'label' => esc_html__( 'Skill Percentage (%)', 'eventalk-core' ),
					'type'  => 'text',
					'desc'  => esc_html__( 'eg. 75', 'eventalk-core' ),
					),
				)
			),
		)
	)
);
/////////////////
// Testimonial //
/////////////////
$EVENTALK_Postmeta->add_meta_box( 'testimonial_info',
	esc_html__( 'Testimonial Information', 'eventalk-core' ), array( "{$prefix}_testimonial" ), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_testimonial_rating" => array(
			'label' => esc_html__( 'Select the Rating', 'eventalk-core' ),
			'type'  => 'select',
			'options' => array(
				'default' => esc_html__( 'Default', 'eventalk-core' ),
				'0'     => '',
				'1'    => '1',
				'2'    => '2',
				'3'    => '3',
				'4'    => '4',
				'5'    => '5'
				),
			'default'  => 'default',
			),
		"{$prefix}_testimonial_designation" => array(
			'label' => esc_html__( 'Designation', 'eventalk-core' ),
			'type'  => 'text',
			'default'  => '',
			)		
		)
	)
);
/////////////////
//	 Schedule  //
/////////////////
$eventalk_event_social = array(
	'facebook' => array(
		'label' => esc_html__( 'Facebook', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-facebook',
		),
	'twitter' => array(
		'label' => esc_html__( 'Twitter', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-twitter',
		),
	'linkedin' => array(
		'label' => esc_html__( 'Linkedin', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-linkedin',
		),
	'gplus' => array(
		'label' => esc_html__( 'Google Plus', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-google-plus',
		),
	'skype' => array(
		'label' => esc_html__( 'Skype', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-skype',
		),
	'youtube' => array(
		'label' => esc_html__( 'Youtube', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-youtube-play',
		),
	'pinterest' => array(
		'label' => esc_html__( 'Pinterest', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-pinterest-p',
		),
	'instagram' => array(
		'label' => esc_html__( 'Instagram', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-instagram',
		),
	'github' => array(
		'label' => esc_html__( 'Github', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-github',
		),
	'stackoverflow' => array(
		'label' => esc_html__( 'Stackoverflow', 'eventalk-core' ),
		'type'  => 'text',
		'icon'  => 'fa-stack-overflow',
		),
	);

$time_picker_format = ( RDTheme::$options['class_time_format'] == 24 ) ? 'time_picker_24' : 'time_picker';
$EVENTALK_Postmeta->add_meta_box( 'schedule_info',
	esc_html__( 'Event Information', 'eventalk-core' ), array( "{$prefix}_event" ), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_event_start_date" => array(
			'label' => esc_html__( 'Start Date', 'eventalk-core' ),
			'type'  => 'date_picker',
			//'format'  => 'mm/dd/yy',
			'default'  => '',
			),
		"{$prefix}_event_start_time" => array(
			'label' => esc_html__( 'Start Time', 'eventalk-core' ),
			'type'  => $time_picker_format,
			'default'  => '',
			),
		"{$prefix}_event_end_date" => array(
			'label' => esc_html__( 'End Date', 'eventalk-core' ),
			'type'  => 'date_picker',
			//'format'  => 'mm/dd/yy',
			'default'  => '',
			),
		"{$prefix}_event_end_time" => array(
			'label' => esc_html__( 'End Time', 'eventalk-core' ),
			'type'  => $time_picker_format,
			'default'  => '',
			),		
		"{$prefix}_event_location" => array(
			'label' => esc_html__( 'Address', 'eventalk-core' ),
			'type'  => 'text',
			'default'  => '',
			),
		
		"{$prefix}_event_ext_link" => array(
			'label' => esc_html__( 'External Web Link', 'eventalk-core' ),
			'type'  => 'text',
			'default'  => '',
			),	
		)
	)
);
/*-------------------------------------
#. Case Study
---------------------------------------*/
$args = array(
	'posts_per_page' => -1,
	'exclude'        => !empty( $_GET['post'] ) ? $_GET['post'] : '',
	'orderby'        => 'title',
	'order'          => 'DESC',
	'post_type'      => "{$prefix}_speaker",
);
$cases = get_posts( $args );
$cases_array = array();
$cases_array = array( '0' => esc_html__( 'Select Speaker', 'eventalk-core' ) );
foreach ( $cases as $case ) {
	$cases_array[$case->ID] = $case->post_title;
}
$EVENTALK_Postmeta->add_meta_box( 'event_schedule', esc_html__( 'Events', 'eventalk-core' ), array( "{$prefix}_event"), '', '', 'high', array(
	'fields' => array(		
		"{$prefix}_event_schedule" => array(
			'type'  => 'repeater',
			'button' => esc_html__( 'Add New Schedule', 'eventalk-core' ),
			'value'  => array(
				'color' => array(
					'label' => esc_html__( 'Color', 'eventalk-core' ),
					'type'  => 'color_picker',
					'desc'  => esc_html__( 'Only Used in Routine Style 2', 'eventalk-core' ),
				),	
				"schedule_label" => array(
					'label' => esc_html__( 'Schedule Label', 'eventalk-core' ),
					'type'  => 'text',
					'default'  => '',
				),
				"session_title" => array(
					'label' => esc_html__( 'Session Title', 'eventalk-core' ),
					'type'  => 'text',
					'default'  => '',
				),		
				"session_start_date" => array(
					'label' => esc_html__( 'Start Date', 'eventalk-core' ),
					'type'  => 'date_picker',
					//'format'  => 'mm/dd/yy',
					'default'  => '',
					),
				"session_start_time" => array(
					'label' => esc_html__( 'Start Time', 'eventalk-core' ),
					'type'  => $time_picker_format,
					'default'  => '',
					),				
				"session_end_time" => array(
					'label' => esc_html__( 'End Time', 'eventalk-core' ),
					'type'  => $time_picker_format,
					'default'  => '',
					),
				'speaker' => array(
					'label' => esc_html__( 'Speaker 1', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,
					
				),	
				'speaker2' => array(
					'label' => esc_html__( 'Speaker 2', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),
				'speaker3' => array(
					'label' => esc_html__( 'Speaker 3', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),
				'speaker4' => array(
					'label' => esc_html__( 'Speaker 4', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),
				'speaker5' => array(
					'label' => esc_html__( 'Speaker 5', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),	
				'speaker6' => array(
					'label' => esc_html__( 'Speaker 6', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),
				'speaker7' => array(
					'label' => esc_html__( 'Speaker 7', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),
				'speaker8' => array(
					'label' => esc_html__( 'Speaker 8', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),
				'speaker9' => array(
					'label' => esc_html__( 'Speaker 9', 'eventalk-core' ),
					'type'  => 'select',
					'options' => $cases_array,					
				),								
				"schedule_Hall" => array(
					'label' => esc_html__( 'Schedule Hall', 'eventalk-core' ),
					'type'  => 'text',
					'default'  => '',
				),
				"session_details" => array(
					'label' => esc_html__( 'Session Details', 'eventalk-core' ),
					'type'  => 'textarea',
					'default'  => '',
				),		
				"session_img" => array(
					'label' => esc_html__( 'Session Image', 'eventalk-core' ),
					'type'  => 'image',
					'default'  => '',
				),	

			)
		),
	)
) );
$EVENTALK_Postmeta->add_meta_box( 'event_socials', esc_html__( 'Event Socials Link', 'eventalk-core' ), array( "{$prefix}_event" ), '', '', 'high', array(
	'fields' => array(
		"{$prefix}_event_socials_header" => array(
			'label' => esc_html__( 'Socials', 'eventalk-core' ),
			'type'  => 'header',
			'desc'  => esc_html__( 'Put your Event links here', 'eventalk-core' ),
			),
		"{$prefix}_event_social" => array(
			'type'  => 'group',
			'value'  => Helper::event_socials()
			),
		)
	)
);


$EVENTALK_Postmeta->add_meta_box( 'event_additional_image', esc_html__( 'Additional Image', 'eventalk-core' ), array( "{$prefix}_event"), '', '', 'high', array(
	'fields' => array(		
		"{$prefix}_event_additional_image" => array(
			'type'  => 'repeater',
			'button' => esc_html__( 'Add New Image', 'eventalk-core' ),
			'value'  => array(				
				"additional_img" => array(
					'label' => esc_html__( 'Additional Image', 'eventalk-core' ),
					'type'  => 'image',
					'default'  => '',
				),	

			)
		),
	)
) );